# Run from an Administrator PowerShell in the project folder
$ErrorActionPreference = "Stop"
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$LhmDir = Join-Path $AppDir "lhm"
$ZipOut = Join-Path $LhmDir "lhm.zip"

Write-Host "=== 1. Downloading LibreHardwareMonitor v0.9.6 ===" -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $LhmDir | Out-Null
Invoke-WebRequest `
    -Uri "https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases/download/v0.9.6/LibreHardwareMonitor.zip" `
    -OutFile $ZipOut
Expand-Archive -Path $ZipOut -DestinationPath $LhmDir -Force
Remove-Item $ZipOut -Force
Get-ChildItem $LhmDir -Recurse | Unblock-File

if (Test-Path (Join-Path $LhmDir "LibreHardwareMonitorLib.dll")) {
    Write-Host "[OK] LibreHardwareMonitorLib.dll ready in $LhmDir" -ForegroundColor Green
} else {
    throw "LibreHardwareMonitorLib.dll not found after extraction."
}

Write-Host "`n=== 2. Checking PawnIO (required for Intel/AMD CPU temps on Windows 11) ===" -ForegroundColor Cyan
$pawnSvc = Get-Service -Name "PawnIO" -ErrorAction SilentlyContinue
if ($null -eq $pawnSvc) {
    Write-Host "PawnIO service not detected. Installing via winget..." -ForegroundColor Yellow
    winget install --id namazso.PawnIO --accept-source-agreements --accept-package-agreements
} else {
    Write-Host "[OK] PawnIO is already installed ($($pawnSvc.Status))." -ForegroundColor Green
}

Write-Host "`n=== 3. Checking NZXT Kraken USB Driver Split (VID 1E71) ===" -ForegroundColor Cyan
Get-PnpDevice | Where-Object { $_.InstanceId -match "VID_1E71" } | ForEach-Object {
    $svc = (Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName "DEVPKEY_Device_Service" -ErrorAction SilentlyContinue).Data
    [PSCustomObject]@{
        Name       = $_.FriendlyName
        Status     = $_.Status
        Driver     = $svc
        InstanceId = $_.InstanceId
    }
} | Format-Table -AutoSize

Write-Host "Expected drivers: MI_00 -> WINUSB, MI_01 -> HidUsb, Parent -> usbccgp." -ForegroundColor Gray
Write-Host "If MI_00 is NOT WINUSB, use Zadig to bind ONLY Interface 0 (MI_00) to WinUSB." -ForegroundColor Gray
