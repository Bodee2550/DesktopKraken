# Run once from an Administrator PowerShell in the project folder
$ErrorActionPreference = "Stop"
$TaskName = "KrakenEliteDashboard"
$AppDir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$PythonW  = (Get-Command pythonw.exe).Source
$MainPy   = Join-Path $AppDir "main.py"

$Action    = New-ScheduledTaskAction -Execute $PythonW -Argument "`"$MainPy`" --minimized" -WorkingDirectory $AppDir
$Trigger   = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$Principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Highest
$Settings  = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -ExecutionTimeLimit (New-TimeSpan -Seconds 0) `
    -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 1)

Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Principal $Principal -Settings $Settings -Force | Out-Null
Write-Host "[OK] Registered elevated logon task '$TaskName' (starts minimized in system tray)." -ForegroundColor Green
Write-Host "     To remove later: .\uninstall_autostart.ps1"
