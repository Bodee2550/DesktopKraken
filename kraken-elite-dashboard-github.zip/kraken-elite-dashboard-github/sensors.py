from __future__ import annotations

import ctypes
import logging
import re
import sys
import winreg
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import psutil
import pynvml

log = logging.getLogger("kraken.sensors")


@dataclass(frozen=True)
class MetricMeta:
    key: str
    label: str
    unit: str
    icon: str                 # thermometer | pulse | power | clock | memory | droplet | none
    default_min: float
    default_max: float
    decimals: int = 0


# Extensible metric registry — add new sensors here and populate in SensorHub.read()
METRICS: dict[str, MetricMeta] = {
    "cpu_temp": MetricMeta("cpu_temp", "CPU Temperature", "°C", "thermometer", 25.0, 95.0, 0),
    "cpu_load": MetricMeta("cpu_load", "CPU Load", "%", "pulse", 0.0, 100.0, 0),
    "cpu_power": MetricMeta("cpu_power", "CPU Power", "W", "power", 0.0, 180.0, 0),
    "cpu_clock": MetricMeta("cpu_clock", "CPU Clock", "MHz", "clock", 800.0, 5600.0, 0),
    "gpu_temp": MetricMeta("gpu_temp", "GPU Temperature", "°C", "thermometer", 25.0, 90.0, 0),
    "gpu_load": MetricMeta("gpu_load", "GPU Load", "%", "pulse", 0.0, 100.0, 0),
    "gpu_power": MetricMeta("gpu_power", "GPU Power", "W", "power", 0.0, 400.0, 0),
    "gpu_clock": MetricMeta("gpu_clock", "GPU Clock", "MHz", "clock", 300.0, 2600.0, 0),
    "gpu_vram_pct": MetricMeta("gpu_vram_pct", "GPU VRAM", "%", "memory", 0.0, 100.0, 0),
    "ram_load": MetricMeta("ram_load", "RAM Usage", "%", "memory", 0.0, 100.0, 0),
    "ram_used_gb": MetricMeta("ram_used_gb", "RAM Used", "GB", "memory", 0.0, 64.0, 1),
    "liquid_temp": MetricMeta("liquid_temp", "Liquid Temp", "°C", "droplet", 20.0, 50.0, 0),
    "none": MetricMeta("none", "None (Hidden)", "", "none", 0.0, 100.0, 0),
}


def format_metric_value(key: str, value: float | None) -> str:
    meta = METRICS.get(key)
    if meta is None or key == "none":
        return ""
    if value is None:
        return "--"
    if meta.decimals == 0:
        return f"{round(value)}{meta.unit}"
    return f"{value:.{meta.decimals}f}{meta.unit}"


def is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _default_lhm_dll() -> Path:
    app_dir = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).parent
    candidates = [app_dir / "lhm" / "LibreHardwareMonitorLib.dll"]
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        candidates.append(Path(meipass) / "lhm" / "LibreHardwareMonitorLib.dll")
    for p in candidates:
        if p.exists():
            return p
    return candidates[0]


def read_registry_cpu_name() -> str | None:
    try:
        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"HARDWARE\DESCRIPTION\System\CentralProcessor\0",
        ) as key:
            val, _ = winreg.QueryValueEx(key, "ProcessorNameString")
            return str(val).strip() if val else None
    except Exception:
        return None


def format_cpu_name(raw: str) -> str:
    name = raw.strip()
    name = re.sub(r"\((?:R|TM|C)\)", "", name, flags=re.IGNORECASE)
    name = re.sub(r"^\d+(?:st|nd|rd|th)\s+Gen\s+", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\b(?:Intel|AMD)\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bwith\s+Radeon.*$", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\b\d+-Core\s+Processor\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\b(?:Processor|CPU)\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"@\s*[\d.]+\s*GHz", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\s+", " ", name).strip(" -")
    return name or "CPU"


def format_gpu_name(raw: str) -> str:
    name = raw.strip()
    name = re.sub(r"\((?:R|TM|C)\)", "", name, flags=re.IGNORECASE)
    name = re.sub(r"^(?:NVIDIA\s+)?GeForce\s+", "", name, flags=re.IGNORECASE)
    name = re.sub(r"^(?:NVIDIA|AMD|Intel)\s+", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bLaptop\s+GPU\b", "Mobile", name, flags=re.IGNORECASE)
    name = re.sub(r"\s+", " ", name).strip(" -")
    return name or "GPU"


def select_cpu_temp(temp_sensors: dict[str, float]) -> tuple[str | None, float]:
    """Select primary CPU temp (Intel 'CPU Package' or AMD 'Core (Tctl/Tdie)'), ignoring TjMax distance."""
    valid = {
        name: val
        for name, val in temp_sensors.items()
        if "distance" not in name.lower() and "tjmax" not in name.lower()
    }
    if not valid:
        return None, 0.0

    lower_map = {k.lower(): k for k in valid}
    for exact in (
        "cpu package",
        "core (tctl/tdie)",
        "tctl/tdie",
        "core max",
        "tdie",
        "core average",
    ):
        if exact in lower_map:
            real_name = lower_map[exact]
            return real_name, valid[real_name]

    for token in ("package", "tctl", "tdie", "core max", "core average"):
        for name, val in valid.items():
            if token in name.lower():
                return name, val

    first_name = next(iter(valid))
    return first_name, valid[first_name]


class SensorHub:
    """Thread-affine hardware sensor reader (initialize & read on the worker thread)."""

    def __init__(self, lhm_dll_path: Path | None = None) -> None:
        self.lhm_dll_path = lhm_dll_path or _default_lhm_dll()
        self.cpu_name = "CPU"
        self.gpu_name = "GPU"
        self.admin = is_admin()
        self.cpu_temp_sensor_name: str = "Unavailable"
        self.warnings: list[str] = []

        self._lhm_computer: Any = None
        self._lhm_cpu_hw: Any = None
        self._lhm_gpu_hw: Any = None
        self._nvml_handle: Any = None

    def open(self) -> None:
        self.warnings.clear()
        psutil.cpu_percent(interval=None)

        reg_cpu = read_registry_cpu_name()
        if reg_cpu:
            self.cpu_name = format_cpu_name(reg_cpu)
            log.info("Detected CPU (Registry): %s -> %s", reg_cpu, self.cpu_name)

        # 1. NVIDIA NVML
        try:
            pynvml.nvmlInit()
            self._nvml_handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            raw_gpu = pynvml.nvmlDeviceGetName(self._nvml_handle)
            raw_str = raw_gpu.decode() if isinstance(raw_gpu, bytes) else str(raw_gpu)
            self.gpu_name = format_gpu_name(raw_str)
            log.info("Detected GPU (NVML): %s -> %s", raw_str, self.gpu_name)
        except Exception as e:
            log.warning("NVML unavailable (falling back to LHM for GPU): %s", e)
            self._nvml_handle = None

        # 2. LibreHardwareMonitorLib (Intel/AMD CPU temp, power, clocks + non-NVIDIA GPU fallback)
        if not self.admin:
            msg = "Not running as Administrator — CPU temperature requires elevation + PawnIO."
            self.warnings.append(msg)
            log.warning(msg)

        if not self.lhm_dll_path.exists():
            msg = f"LibreHardwareMonitorLib.dll missing at {self.lhm_dll_path}"
            self.warnings.append(msg)
            log.warning(msg)
            return

        try:
            import clr  # type: ignore

            clr.AddReference(str(self.lhm_dll_path.resolve()))
            from LibreHardwareMonitor import Hardware  # type: ignore

            comp = Hardware.Computer()
            comp.IsCpuEnabled = True
            comp.IsGpuEnabled = self._nvml_handle is None
            comp.Open()
            self._lhm_computer = comp

            for hw in comp.Hardware:
                if hw.HardwareType == Hardware.HardwareType.Cpu:
                    self._lhm_cpu_hw = hw
                    hw.Update()
                    if self.cpu_name == "CPU" and str(hw.Name).strip():
                        self.cpu_name = format_cpu_name(str(hw.Name))
                    log.info("LHM CPU attached: %s", hw.Name)
                elif self._nvml_handle is None and "Gpu" in str(hw.HardwareType):
                    self._lhm_gpu_hw = hw
                    hw.Update()
                    self.gpu_name = format_gpu_name(str(hw.Name))
                    log.info("LHM GPU fallback attached: %s", hw.Name)
        except Exception as e:
            msg = f"LibreHardwareMonitorLib failed to load: {e}"
            self.warnings.append(msg)
            log.error(msg)

    def read(self, liquid_temp: float | None = None) -> dict[str, Any]:
        vm = psutil.virtual_memory()
        snap: dict[str, Any] = {
            "cpu_name": self.cpu_name,
            "gpu_name": self.gpu_name,
            "cpu_temp": 0.0,
            "cpu_load": float(psutil.cpu_percent(interval=None)),
            "cpu_power": None,
            "cpu_clock": None,
            "gpu_temp": 0.0,
            "gpu_load": 0.0,
            "gpu_power": None,
            "gpu_clock": None,
            "gpu_vram_pct": None,
            "ram_load": float(vm.percent),
            "ram_used_gb": float(vm.used) / (1024.0 ** 3),
            "liquid_temp": liquid_temp,
            "cpu_temp_sensor": self.cpu_temp_sensor_name,
        }

        if self._lhm_cpu_hw is not None:
            try:
                self._lhm_cpu_hw.Update()
                temps: dict[str, float] = {}
                clocks: list[float] = []
                for s in self._lhm_cpu_hw.Sensors:
                    if s.Value is None:
                        continue
                    stype = str(s.SensorType)
                    sname = str(s.Name)
                    val = float(s.Value)
                    if stype == "Temperature":
                        temps[sname] = val
                    elif stype == "Power" and "package" in sname.lower():
                        snap["cpu_power"] = val
                    elif stype == "Clock" and "core" in sname.lower() and "bus" not in sname.lower():
                        clocks.append(val)

                chosen, ctemp = select_cpu_temp(temps)
                if chosen:
                    snap["cpu_temp"] = ctemp
                    if self.cpu_temp_sensor_name != chosen:
                        self.cpu_temp_sensor_name = chosen
                        log.info("Selected CPU temp sensor: %s (%.1f°C)", chosen, ctemp)
                    snap["cpu_temp_sensor"] = chosen
                if clocks:
                    snap["cpu_clock"] = max(clocks)
            except Exception as e:
                log.warning("CPU sensor read error: %s", e)

        if self._nvml_handle is not None:
            try:
                snap["gpu_temp"] = float(
                    pynvml.nvmlDeviceGetTemperature(self._nvml_handle, pynvml.NVML_TEMPERATURE_GPU)
                )
                util = pynvml.nvmlDeviceGetUtilizationRates(self._nvml_handle)
                snap["gpu_load"] = float(util.gpu)
                try:
                    snap["gpu_power"] = float(pynvml.nvmlDeviceGetPowerUsage(self._nvml_handle)) / 1000.0
                except Exception:
                    pass
                try:
                    snap["gpu_clock"] = float(
                        pynvml.nvmlDeviceGetClockInfo(self._nvml_handle, pynvml.NVML_CLOCK_GRAPHICS)
                    )
                except Exception:
                    pass
                try:
                    mem = pynvml.nvmlDeviceGetMemoryInfo(self._nvml_handle)
                    if mem.total > 0:
                        snap["gpu_vram_pct"] = (float(mem.used) / float(mem.total)) * 100.0
                except Exception:
                    pass
            except Exception as e:
                log.warning("NVML read error: %s", e)
        elif self._lhm_gpu_hw is not None:
            try:
                self._lhm_gpu_hw.Update()
                for s in self._lhm_gpu_hw.Sensors:
                    if s.Value is None:
                        continue
                    stype = str(s.SensorType)
                    sname = str(s.Name).lower()
                    val = float(s.Value)
                    if stype == "Temperature" and "core" in sname and snap["gpu_temp"] == 0.0:
                        snap["gpu_temp"] = val
                    elif stype == "Load" and "core" in sname and snap["gpu_load"] == 0.0:
                        snap["gpu_load"] = val
                    elif stype == "Power" and snap["gpu_power"] is None:
                        snap["gpu_power"] = val
                    elif stype == "Clock" and "core" in sname and snap["gpu_clock"] is None:
                        snap["gpu_clock"] = val
            except Exception as e:
                log.warning("LHM GPU fallback read error: %s", e)

        return snap

    def close(self) -> None:
        if self._lhm_computer is not None:
            try:
                self._lhm_computer.Close()
            except Exception:
                pass
            self._lhm_computer = None
            self._lhm_cpu_hw = None
            self._lhm_gpu_hw = None
        if self._nvml_handle is not None:
            try:
                pynvml.nvmlShutdown()
            except Exception:
                pass
            self._nvml_handle = None
