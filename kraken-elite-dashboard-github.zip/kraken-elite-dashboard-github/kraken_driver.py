from __future__ import annotations

import logging
import struct
import subprocess
import time
from dataclasses import dataclass

import hid
import libusb_package
import psutil
import usb.core
import usb.util

log = logging.getLogger("kraken.usb")

NZXT_VID = 0x1E71
SUPPORTED_PIDS: dict[int, str] = {
    0x300C: "NZXT Kraken 2023 Elite",
    0x3012: "NZXT Kraken Elite V2 (2024)",
}

LCD_WIDTH = 640
LCD_HEIGHT = 640
RGBX_FRAME_BYTES = LCD_WIDTH * LCD_HEIGHT * 4       # 1,638,400 bytes
SLOT_STRIDE_BLOCKS = 0x1000                         # 4,096 KB (4 MB) per double-buffer slot
MAX_GIF_BYTES = (SLOT_STRIDE_BLOCKS * 1024) - 2048  # Safe margin inside 4 MB slot
SWITCH_MODE_CUSTOM = 0x04
BULK_CHUNK_SIZE = 256 * 1024
BULK_MAGIC = bytes([0x12, 0xFA, 0x01, 0xE8, 0xAB, 0xCD, 0xEF, 0x98, 0x76, 0x54, 0x32, 0x10])


@dataclass
class DeviceInfo:
    model: str = "Not Connected"
    vid: int = 0
    pid: int = 0
    firmware: str = "Unknown"
    width: int = LCD_WIDTH
    height: int = LCD_HEIGHT
    brightness: int = 100
    orientation_deg: int = 0


def check_cam_conflicts() -> list[str]:
    """Detect if NZXT CAM or CAMService is active and could contend for USB handles."""
    warnings: list[str] = []
    try:
        res = subprocess.run(
            ["sc", "query", "CAMService"],
            capture_output=True,
            text=True,
            timeout=2,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            check=False,
        )
        if "RUNNING" in res.stdout:
            warnings.append("CAMService is RUNNING (disable it via PowerShell so it cannot hijack the LCD).")
    except Exception:
        pass

    try:
        for proc in psutil.process_iter(["name"]):
            pname = (proc.info.get("name") or "").lower()
            if "nzxt cam" in pname or pname in ("cam_helper.exe", "nzxtcam.exe"):
                warnings.append(f"Process '{proc.info.get('name')}' is running — close NZXT CAM completely.")
                break
    except Exception:
        pass
    return warnings


class KrakenDriver:
    """Direct double-buffered WinUSB + HID driver for NZXT Kraken Elite 640x640 LCDs."""

    def __init__(self) -> None:
        self.hid_dev = None
        self.usb_dev = None
        self.info = DeviceInfo()
        self.active_bucket: int | None = None
        self.occupied: set[int] = set()
        self.pending_cleanup: list[int] = []
        self._last_brightness: int | None = None
        self._last_orientation: int | None = None
        self._hw_orientation_byte: int = 0

    @property
    def is_connected(self) -> bool:
        return self.hid_dev is not None and self.usb_dev is not None

    def open(self) -> DeviceInfo:
        self.close()
        backend = libusb_package.get_libusb1_backend()

        found_pid: int | None = None
        found_model: str = ""
        hid_path = None

        for pid, model in SUPPORTED_PIDS.items():
            candidates = hid.enumerate(NZXT_VID, pid)
            if candidates:
                chosen = next((d for d in candidates if d.get("interface_number") == 1), candidates[0])
                hid_path = chosen["path"]
                found_pid = pid
                found_model = model
                break

        if found_pid is None or hid_path is None:
            raise RuntimeError("No supported NZXT Kraken Elite (1e71:300c / 1e71:3012) found on HID.")

        usb_dev = usb.core.find(idVendor=NZXT_VID, idProduct=found_pid, backend=backend)
        if usb_dev is None:
            raise RuntimeError(
                f"Found {found_model} HID control interface, but Bulk interface (MI_00 / WinUSB) "
                f"is unavailable via libusb."
            )

        try:
            hid_dev = hid.device()
            hid_dev.open_path(hid_path)
            usb.util.claim_interface(usb_dev, 0)
        except Exception:
            try:
                usb.util.dispose_resources(usb_dev)
            except Exception:
                pass
            raise

        self.hid_dev = hid_dev
        self.usb_dev = usb_dev
        self.active_bucket = None
        self.occupied = set()
        self.pending_cleanup = []

        fw = self._query_firmware()
        lcd = self.query_lcd_info()
        self._hw_orientation_byte = (lcd["orientation_deg"] // 90) % 4
        self.info = DeviceInfo(
            model=found_model,
            vid=NZXT_VID,
            pid=found_pid,
            firmware=fw,
            width=lcd["width"],
            height=lcd["height"],
            brightness=lcd["brightness"],
            orientation_deg=lcd["orientation_deg"],
        )
        self._last_brightness = lcd["brightness"]
        self._last_orientation = lcd["orientation_deg"]

        self._prepare_double_buffer()
        log.info(
            "Connected: %s (%04x:%04x) fw=%s res=%dx%d bright=%d%% hw_orient=%d°",
            self.info.model,
            self.info.vid,
            self.info.pid,
            self.info.firmware,
            self.info.width,
            self.info.height,
            self.info.brightness,
            lcd["orientation_deg"],
        )
        return self.info

    def close(self) -> None:
        if self.usb_dev is not None:
            try:
                usb.util.release_interface(self.usb_dev, 0)
            except Exception:
                pass
            try:
                usb.util.dispose_resources(self.usb_dev)
            except Exception:
                pass
            self.usb_dev = None
        if self.hid_dev is not None:
            try:
                self.hid_dev.close()
            except Exception:
                pass
            self.hid_dev = None
        self.active_bucket = None
        self.occupied.clear()
        self.pending_cleanup.clear()

    def _drain_hid(self) -> None:
        if self.hid_dev is None:
            return
        for _ in range(16):
            if not self.hid_dev.read(64, timeout_ms=1):
                break

    def _send_hid_raw(self, report_id: int, subcmd: int, data: bytes = b"") -> None:
        if self.hid_dev is None:
            raise RuntimeError("HID device not open")
        buf = bytearray(64)
        buf[0] = report_id
        buf[1] = subcmd
        buf[2 : 2 + len(data)] = data
        written = self.hid_dev.write(bytes(buf))
        if written <= 0:
            raise IOError(f"HID write failed for {report_id:#04x}:{subcmd:#04x}")

    def _hid_cmd(self, report_id: int, subcmd: int, data: bytes = b"", timeout_ms: int = 2000) -> list[int]:
        self._drain_hid()
        self._send_hid_raw(report_id, subcmd, data)
        expected_rid = (report_id + 1) & 0xFF
        deadline = time.perf_counter() + (timeout_ms / 1000.0)
        while time.perf_counter() < deadline:
            rem = max(1, int((deadline - time.perf_counter()) * 1000))
            reply = self.hid_dev.read(64, timeout_ms=min(rem, 250))
            if not reply:
                continue
            if reply[0] == expected_rid and reply[1] == subcmd:
                return reply
            if reply[0] == 0xFF and reply[1] == 0x01 and reply[14] == report_id and reply[15] == subcmd:
                return reply
        raise TimeoutError(f"HID timeout waiting for {expected_rid:#04x}:{subcmd:#04x}")

    def _query_firmware(self) -> str:
        try:
            r = self._hid_cmd(0x10, 0x01, timeout_ms=1000)
            return f"{r[17]}.{r[18]}.{r[19]}"
        except Exception:
            return "Unknown"

    def query_lcd_info(self) -> dict[str, int]:
        r = self._hid_cmd(0x30, 0x01)
        return {
            "width": r[20] | (r[21] << 8),
            "height": r[22] | (r[23] << 8),
            "brightness": r[24],
            "orientation_deg": (r[26] % 4) * 90,
        }

    def set_display_settings(self, brightness: int, orientation_deg: int, force: bool = False) -> None:
        """Apply hardware brightness over HID; custom frame orientation is handled in software."""
        brightness = max(0, min(100, int(brightness)))
        orient_deg_clean = (int(orientation_deg) // 90) % 4 * 90
        self.info.orientation_deg = orient_deg_clean
        self._last_orientation = orient_deg_clean

        if not force and self._last_brightness == brightness:
            return

        payload = bytes([0x01, brightness, 0x00, 0x00, 0x01, self._hw_orientation_byte])
        try:
            self._hid_cmd(0x30, 0x02, payload, timeout_ms=1000)
            self._last_brightness = brightness
            self.info.brightness = brightness
            log.info("Applied LCD brightness=%d%% (software orientation=%d°)", brightness, orient_deg_clean)
        except Exception as e:
            log.warning("Brightness HID command skipped (%s)", e)

    def read_liquid_temp(self) -> float | None:
        """Optionally poll AIO liquid temperature via HID 0x74 0x01; returns None if unavailable."""
        if not self.is_connected:
            return None
        try:
            r = self._hid_cmd(0x74, 0x01, timeout_ms=200)
            temp = float(r[15]) + float(r[16]) / 10.0
            if 5.0 <= temp <= 90.0:
                return temp
        except Exception:
            pass
        return None

    def _prepare_double_buffer(self) -> None:
        self._hid_cmd(0x36, 0x03)
        self.occupied = set()
        for idx in range(16):
            r = self._hid_cmd(0x30, 0x04, bytes([idx]))
            if r[15] != 0:
                self.occupied.add(idx)

        for idx in sorted(b for b in self.occupied if b >= 2):
            if not self._delete_bucket(idx):
                self.pending_cleanup.append(idx)

    def _delete_bucket(self, idx: int) -> bool:
        r = self._hid_cmd(0x32, 0x02, bytes([idx]))
        if r[14] == 1:
            self.occupied.discard(idx)
            return True
        return False

    def _create_bucket(self, idx: int, offset_blocks: int, size_blocks: int) -> bool:
        payload = struct.pack("<BBHHB", idx, idx + 1, offset_blocks, size_blocks, 0x01)
        r = self._hid_cmd(0x32, 0x01, payload)
        if r[14] == 1:
            self.occupied.add(idx)
            return True
        return False

    def _push_payload(self, payload: bytes, bulk_type: int) -> float:
        if not self.is_connected:
            raise RuntimeError("Kraken device is not connected.")

        size_blocks = (len(payload) + 20 + 1023) // 1024
        if size_blocks > SLOT_STRIDE_BLOCKS:
            raise ValueError(
                f"Payload too large for 4 MB double-buffer slot ({len(payload)} bytes / {size_blocks} blocks)"
            )

        t0 = time.perf_counter()
        candidates = [1, 0] if self.active_bucket is None else [1 - self.active_bucket]
        target: int | None = None

        for slot in candidates:
            offset = slot * SLOT_STRIDE_BLOCKS
            if slot in self.occupied and not self._delete_bucket(slot):
                continue
            if self._create_bucket(slot, offset, size_blocks):
                target = slot
                break

        if target is None:
            raise RuntimeError("Device refused bucket allocation for double-buffer slots 0 and 1.")

        r_start = self._hid_cmd(0x36, 0x01, bytes([target]))
        if r_start[14] != 1:
            raise RuntimeError(f"Bulk start failed on slot {target} (status={r_start[14]})")

        header = BULK_MAGIC + struct.pack("<II", bulk_type, len(payload))
        self.usb_dev.write(0x02, header, timeout=5000)
        mv = memoryview(payload)
        for off in range(0, len(payload), BULK_CHUNK_SIZE):
            self.usb_dev.write(0x02, mv[off : off + BULK_CHUNK_SIZE], timeout=10000)

        self._send_hid_raw(0x36, 0x02)
        if bulk_type == 1:
            time.sleep(0.015)

        r_sw = self._hid_cmd(0x38, 0x01, bytes([SWITCH_MODE_CUSTOM, target]))
        if r_sw[14] != 1:
            raise RuntimeError(f"Switch active bucket failed (slot={target}, status={r_sw[14]})")

        self.active_bucket = target
        for old in list(self.pending_cleanup):
            if self._delete_bucket(old):
                self.pending_cleanup.remove(old)

        return (time.perf_counter() - t0) * 1000.0

    def push_rgbx(self, rgbx_bytes: bytes) -> float:
        if len(rgbx_bytes) != RGBX_FRAME_BYTES:
            raise ValueError(f"Expected {RGBX_FRAME_BYTES} RGBX bytes, got {len(rgbx_bytes)}")
        return self._push_payload(rgbx_bytes, bulk_type=2)

    def push_gif(self, gif_bytes: bytes) -> float:
        return self._push_payload(gif_bytes, bulk_type=1)

    def push_black_frame(self) -> None:
        self.push_rgbx(bytes(RGBX_FRAME_BYTES))
