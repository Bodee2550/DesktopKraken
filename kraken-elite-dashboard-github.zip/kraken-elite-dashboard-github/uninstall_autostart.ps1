# Removes the KrakenEliteDashboard Task Scheduler auto-start entry
$TaskName = "KrakenEliteDashboard"
if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "[OK] Removed scheduled task '$TaskName'." -ForegroundColor Green
} else {
    Write-Host "[INFO] Scheduled task '$TaskName' was not installed." -ForegroundColor Yellow
}
