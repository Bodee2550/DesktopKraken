from __future__ import annotations

import argparse
import ctypes
import ctypes.wintypes
import logging
import os
import subprocess
import sys
import threading
import time
from collections import deque
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any

from PySide6.QtCore import QByteArray, Qt, QThread, QTimer, Signal
from PySide6.QtGui import (
    QAction,
    QColor,
    QIcon,
    QImage,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
)
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSlider,
    QSpinBox,
    QSystemTrayIcon,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from config import APP_DIR, AppConfig, ProfileConfig, clone_config, load_config, save_config
from kraken_driver import LCD_HEIGHT, LCD_WIDTH, KrakenDriver, check_cam_conflicts
from renderer import FONT_MAP, DualInfoRenderer
from sensors import METRICS, SensorHub, format_metric_value, is_admin

# --- Windows Power & USB Broadcast Constants ---
WM_POWERBROADCAST = 0x0218
PBT_APMSUSPEND = 0x0004
PBT_APMRESUMESUSPEND = 0x0007
PBT_APMRESUMEAUTOMATIC = 0x0012

WM_DEVICECHANGE = 0x0219
DBT_DEVNODES_CHANGED = 0x0007
DBT_DEVICEARRIVAL = 0x8000
DBT_DEVICEREMOVECOMPLETE = 0x8004

LOG_DIR = APP_DIR / "logs"
LOG_FILE = LOG_DIR / "kraken_dashboard.log"

log = logging.getLogger("kraken.app")


class MemoryLogHandler(logging.Handler):
    def __init__(self, maxlen: int = 250) -> None:
        super().__init__()
        self.lines: deque[str] = deque(maxlen=maxlen)
        self.callback = None

    def emit(self, record: logging.LogRecord) -> None:
        msg = self.format(record)
        self.lines.append(msg)
        if self.callback is not None:
            try:
                self.callback(msg)
            except Exception:
                pass


def setup_logging() -> MemoryLogHandler:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s", "%Y-%m-%d %H:%M:%S")

    root = logging.getLogger()
    root.setLevel(logging.INFO)

    fh = RotatingFileHandler(LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    root.addHandler(fh)

    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    root.addHandler(sh)

    mh = MemoryLogHandler()
    mh.setFormatter(fmt)
    root.addHandler(mh)
    return mh


def acquire_single_instance_mutex() -> Any:
    mutex = ctypes.windll.kernel32.CreateMutexW(None, False, "Local\\KrakenEliteStandaloneDashboard_v1")
    if ctypes.windll.kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
        return None
    return mutex


def build_tray_icon() -> QIcon:
    pix = QPixmap(64, 64)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setBrush(QColor(15, 22, 36))
    p.setPen(QPen(QColor(60, 72, 92), 3))
    p.drawEllipse(4, 4, 56, 56)
    p.setPen(QPen(QColor(0, 174, 240), 6, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
    p.drawArc(10, 10, 44, 44, 125 * 16, 110 * 16)
    p.setPen(QPen(QColor(122, 184, 0), 6, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
    p.drawArc(10, 10, 44, 44, -55 * 16, 110 * 16)
    p.end()
    return QIcon(pix)


class DisplayWorker(QThread):
    """Owns sensors, renderer, direct USB driver, and sleep/wake + reconnect watchdog."""

    status_changed = Signal(str, bool)
    device_info_changed = Signal(dict)
    stats_updated = Signal(dict)
    preview_updated = Signal(QImage)
    cam_warnings_changed = Signal(list)

    def __init__(self, initial_cfg: AppConfig) -> None:
        super().__init__()
        self._lock = threading.Lock()
        self._cfg = clone_config(initial_cfg)
        self._wake_event = threading.Event()
        self._stop_requested = False
        self._sleeping = False
        self._force_reconnect = False
        self._config_dirty = True
        self._paused = False
        self._preview_visible = True
        self._resume_not_before = 0.0

    def update_config(self, cfg: AppConfig) -> None:
        with self._lock:
            self._cfg = clone_config(cfg)
            self._config_dirty = True
        self._wake_event.set()

    def set_preview_visible(self, visible: bool) -> None:
        with self._lock:
            self._preview_visible = visible
        if visible:
            self._wake_event.set()

    def request_sleep(self) -> None:
        log.info("System SUSPEND event received — preparing LCD for sleep.")
        with self._lock:
            self._sleeping = True
        self._wake_event.set()

    def request_wake(self, settle_seconds: float = 2.5) -> None:
        log.info("System RESUME event received — scheduling USB re-init in %.1fs.", settle_seconds)
        with self._lock:
            self._sleeping = False
            self._force_reconnect = True
            self._resume_not_before = time.monotonic() + settle_seconds
        self._wake_event.set()

    def request_usb_change(self) -> None:
        with self._lock:
            if not self._sleeping:
                self._wake_event.set()

    def request_reconnect(self) -> None:
        log.info("Manual LCD reconnect requested.")
        with self._lock:
            self._sleeping = False
            self._force_reconnect = True
            self._resume_not_before = 0.0
        self._wake_event.set()

    def set_paused(self, paused: bool) -> None:
        with self._lock:
            self._paused = paused
        self._wake_event.set()

    def stop(self) -> None:
        self._stop_requested = True
        self._wake_event.set()

    def run(self) -> None:
        sensors = SensorHub()
        sensors.open()
        renderer = DualInfoRenderer()
        driver = KrakenDriver()

        backoff = 1.0
        last_gif_sig = None
        last_push_ts = 0.0
        last_sensor_ts = 0.0
        last_cam_check = 0.0
        last_stats: dict[str, Any] | None = None
        gif_epoch_ts = time.monotonic()
        gif_phase_base = 0
        was_sleeping = False

        self.status_changed.emit("Searching for Kraken Elite...", False)

        try:
            while not self._stop_requested:
                now = time.monotonic()

                if now - last_cam_check > 15.0:
                    last_cam_check = now
                    self.cam_warnings_changed.emit(check_cam_conflicts())

                with self._lock:
                    cfg = clone_config(self._cfg)
                    profile = cfg.current_profile()
                    sleeping = self._sleeping
                    paused = self._paused
                    preview_vis = self._preview_visible
                    force_reconn = self._force_reconnect
                    resume_wait = self._resume_not_before - now
                    cfg_dirty = self._config_dirty
                    self._config_dirty = False
                    if force_reconn and resume_wait <= 0:
                        self._force_reconnect = False

                # --- SLEEP STATE ---
                if sleeping:
                    if not was_sleeping:
                        was_sleeping = True
                        if driver.is_connected:
                            try:
                                if cfg.blank_on_sleep:
                                    log.info("Blanking/dimming LCD for sleep.")
                                    driver.set_display_settings(0, profile.orientation, force=True)
                                    driver.push_black_frame()
                            except Exception as e:
                                log.warning("Sleep blank step skipped (%s)", e)
                            driver.close()
                        self.status_changed.emit("System sleeping (USB released)", False)
                    self._wake_event.wait(timeout=1.0)
                    self._wake_event.clear()
                    continue

                if was_sleeping:
                    was_sleeping = False
                    last_gif_sig = None

                # --- POST-WAKE SETTLE DELAY ---
                if resume_wait > 0:
                    self.status_changed.emit(f"Waking up (USB settle {resume_wait:.1f}s)...", False)
                    self._wake_event.wait(timeout=min(0.5, resume_wait))
                    self._wake_event.clear()
                    continue

                # --- FORCE RECONNECT ---
                if force_reconn:
                    driver.close()
                    last_gif_sig = None
                    backoff = 1.0

                # --- SENSOR POLLING (decoupled at 1 Hz so GIF preview runs smoothly at 20-30 FPS) ---
                if last_stats is None or cfg_dirty or (now - last_sensor_ts) >= 1.0:
                    liquid_temp = driver.read_liquid_temp() if driver.is_connected else None
                    last_stats = sensors.read(liquid_temp=liquid_temp)
                    last_sensor_ts = now
                    self.stats_updated.emit(last_stats)
                stats = last_stats

                # --- CONNECT / WATCHDOG ---
                if not driver.is_connected:
                    try:
                        info = driver.open()
                        driver.set_display_settings(profile.brightness, profile.orientation, force=True)
                        backoff = 1.0
                        last_gif_sig = None
                        self.device_info_changed.emit(
                            {
                                "model": info.model,
                                "vid_pid": f"{info.vid:04X}:{info.pid:04X}",
                                "firmware": info.firmware,
                                "resolution": f"{info.width}x{info.height}",
                                "brightness": info.brightness,
                                "orientation": info.orientation_deg,
                            }
                        )
                        self.status_changed.emit(f"Connected: {info.model} (fw {info.firmware})", True)
                    except Exception as e:
                        if preview_vis:
                            try:
                                idx = renderer.gif_frame_at_elapsed(now - gif_epoch_ts)
                                preview_rgba = renderer.render_frame_rgba(profile, stats, idx)
                                self._emit_preview(preview_rgba)
                            except Exception:
                                pass
                        log.warning("Kraken not ready (%s) — retrying in %.1fs", e, backoff)
                        self.status_changed.emit(f"Disconnected — retrying in {backoff:.0f}s", False)
                        self._wake_event.wait(timeout=backoff)
                        self._wake_event.clear()
                        backoff = min(15.0, backoff * 2.0)
                        continue

                if paused:
                    if preview_vis:
                        idx = renderer.gif_frame_at_elapsed(now - gif_epoch_ts)
                        preview_rgba = renderer.render_frame_rgba(profile, stats, idx)
                        self._emit_preview(preview_rgba)
                    self.status_changed.emit("Paused", True)
                    self._wake_event.wait(timeout=0.5)
                    self._wake_event.clear()
                    continue

                # --- APPLY SETTINGS & RENDER / PUSH FRAME ---
                try:
                    if cfg_dirty:
                        last_gif_sig = None

                    driver.set_display_settings(profile.brightness, profile.orientation)
                    renderer.ensure_background(profile)

                    if renderer.is_animated_gif:
                        sig = renderer.state_signature(profile, stats)
                        min_gap = max(1.0, float(profile.gif_update_interval_sec))
                        need_push = (
                            cfg_dirty
                            or last_gif_sig is None
                            or (sig != last_gif_sig and (now - last_push_ts) >= min_gap)
                        )
                        if need_push:
                            cur_phase = (
                                (gif_phase_base + renderer.gif_frame_at_elapsed(now - gif_epoch_ts))
                                % max(1, renderer.gif_frame_count)
                            )
                            gif_bytes, preview_rgba, meta = renderer.render_gif(
                                profile, stats, start_frame=cur_phase
                            )
                            if preview_vis:
                                self._emit_preview(preview_rgba)
                            push_ms = driver.push_gif(gif_bytes)
                            last_gif_sig = sig
                            last_push_ts = time.monotonic()
                            gif_epoch_ts = last_push_ts
                            gif_phase_base = cur_phase
                            log.info(
                                "GIF pushed: %d frames @ %.1f FPS (%d colors, %.0f KB) | encode=%.0fms usb=%.0fms",
                                meta["frames"],
                                meta["fps"],
                                meta["colors"],
                                meta["size_kb"],
                                meta["encode_ms"],
                                push_ms,
                            )
                        elif preview_vis:
                            cur_idx = (
                                (gif_phase_base + renderer.gif_frame_at_elapsed(now - gif_epoch_ts))
                                % max(1, renderer.gif_frame_count)
                            )
                            preview_rgba = renderer.render_frame_rgba(profile, stats, cur_idx)
                            self._emit_preview(preview_rgba)

                        if preview_vis:
                            cur_idx = (
                                (gif_phase_base + renderer.gif_frame_at_elapsed(time.monotonic() - gif_epoch_ts))
                                % max(1, renderer.gif_frame_count)
                            )
                            wait_s = max(0.033, min(0.10, renderer.gif_frame_duration_ms(cur_idx) / 1000.0))
                        else:
                            wait_s = max(0.15, 1.0 - (time.monotonic() - last_sensor_ts))
                    else:
                        last_gif_sig = None
                        rgbx, preview_rgba = renderer.render_rgbx(profile, stats)
                        if preview_vis:
                            self._emit_preview(preview_rgba)
                        driver.push_rgbx(rgbx)
                        last_push_ts = time.monotonic()
                        elapsed = last_push_ts - now
                        wait_s = max(0.05, float(profile.update_interval_sec) - elapsed)

                    self._wake_event.wait(timeout=wait_s)
                    self._wake_event.clear()

                except Exception as e:
                    log.error("USB transfer error (%s) — closing handles for recovery.", e)
                    driver.close()
                    last_gif_sig = None
                    self.status_changed.emit("USB write error — reconnecting...", False)
                    self._wake_event.wait(timeout=1.0)
                    self._wake_event.clear()
        finally:
            if driver.is_connected:
                try:
                    with self._lock:
                        prof = self._cfg.current_profile()
                    driver.set_display_settings(prof.brightness, prof.orientation)
                except Exception:
                    pass
                driver.close()
            sensors.close()
            log.info("DisplayWorker stopped cleanly.")

    def _emit_preview(self, rgba_img) -> None:
        raw = rgba_img.tobytes("raw", "RGBA")
        qimg = QImage(raw, LCD_WIDTH, LCD_HEIGHT, LCD_WIDTH * 4, QImage.Format.Format_RGBA8888).copy()
        self.preview_updated.emit(qimg)


class CircularPreviewWidget(QWidget):
    """1:1 circular live preview widget matching the Kraken Elite bezel."""

    def __init__(self, diameter: int = 320) -> None:
        super().__init__()
        self._diameter = diameter
        self._image: QImage | None = None
        self.setFixedSize(diameter + 24, diameter + 24)

    def set_image(self, img: QImage) -> None:
        self._image = img
        self.update()

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

        cx = self.width() // 2
        cy = self.height() // 2
        r = self._diameter // 2

        p.setBrush(QColor(22, 24, 30))
        p.setPen(QPen(QColor(58, 62, 74), 3))
        p.drawEllipse(cx - r - 8, cy - r - 8, self._diameter + 16, self._diameter + 16)

        path = QPainterPath()
        path.addEllipse(cx - r, cy - r, self._diameter, self._diameter)
        p.setClipPath(path)

        if self._image is not None:
            p.drawImage(
                cx - r,
                cy - r,
                self._image.scaled(
                    self._diameter,
                    self._diameter,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                ),
            )
        else:
            p.fillRect(cx - r, cy - r, self._diameter, self._diameter, QColor(12, 16, 26))
            p.setPen(QColor(160, 175, 200))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "Waiting for frame...")
        p.end()


class ColorButton(QPushButton):
    color_changed = Signal(str)

    def __init__(self, hex_color: str) -> None:
        super().__init__()
        self._hex = hex_color
        self.setFixedWidth(78)
        self._refresh_style()
        self.clicked.connect(self._pick)

    def set_color(self, hex_color: str) -> None:
        self._hex = hex_color
        self._refresh_style()

    def color(self) -> str:
        return self._hex

    def _refresh_style(self) -> None:
        self.setText(self._hex.upper())
        self.setStyleSheet(
            f"background-color: {self._hex}; color: #111; font-weight: bold; border: 1px solid #555; padding: 3px;"
        )

    def _pick(self) -> None:
        chosen = QColorDialog.getColor(QColor(self._hex), self, "Select Color")
        if chosen.isValid():
            self._hex = chosen.name().upper()
            self._refresh_style()
            self.color_changed.emit(self._hex)


class MainWindow(QMainWindow):
    def __init__(self, cfg: AppConfig, log_handler: MemoryLogHandler, start_minimized: bool = False) -> None:
        super().__init__()
        self.cfg = cfg
        self.log_handler = log_handler
        self._loading_ui = False
        self._really_quit = False

        self.setWindowTitle("Kraken Elite Standalone Dashboard")
        self.setWindowIcon(build_tray_icon())
        self.resize(960, 650)

        # Ensure native Windows HWND is allocated immediately so WM_POWERBROADCAST works even when minimized
        _ = int(self.winId())

        self.worker = DisplayWorker(self.cfg)
        self._build_ui()
        self._build_tray()
        self._load_profile_into_ui()

        self.worker.status_changed.connect(self._on_status)
        self.worker.device_info_changed.connect(self._on_device_info)
        self.worker.stats_updated.connect(self._on_stats)
        self.worker.preview_updated.connect(self.preview.set_image)
        self.worker.cam_warnings_changed.connect(self._on_cam_warnings)

        self._log_timer = QTimer(self)
        self._log_timer.setInterval(1000)
        self._log_timer.timeout.connect(self._refresh_log_tail)
        self._log_timer.start()

        self.worker.set_preview_visible(not start_minimized)
        self.worker.start()

        if start_minimized:
            self.hide()
        else:
            self.show()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self.worker.set_preview_visible(True)

    def hideEvent(self, event) -> None:
        super().hideEvent(event)
        self.worker.set_preview_visible(False)

    # --- Native Windows Power & USB Event Hook ---
    def nativeEvent(self, eventType: QByteArray | bytes, message: int):
        if eventType in (b"windows_generic_MSG", b"windows_dispatcher_MSG"):
            try:
                msg = ctypes.wintypes.MSG.from_address(int(message))
                if msg.message == WM_POWERBROADCAST:
                    if msg.wParam == PBT_APMSUSPEND:
                        self.worker.request_sleep()
                    elif msg.wParam in (PBT_APMRESUMEAUTOMATIC, PBT_APMRESUMESUSPEND):
                        self.worker.request_wake(settle_seconds=2.5)
                elif msg.message == WM_DEVICECHANGE:
                    if msg.wParam in (DBT_DEVICEARRIVAL, DBT_DEVICEREMOVECOMPLETE, DBT_DEVNODES_CHANGED):
                        self.worker.request_usb_change()
            except Exception as e:
                log.debug("nativeEvent parse note: %s", e)
        return super().nativeEvent(eventType, message)

    def _build_tray(self) -> None:
        self.tray = QSystemTrayIcon(build_tray_icon(), self)
        self.tray.setToolTip("Kraken Elite Standalone Dashboard")
        self.tray.activated.connect(self._on_tray_activated)
        self._rebuild_tray_menu()
        self.tray.show()

    def _rebuild_tray_menu(self) -> None:
        menu = QMenu(self)
        act_open = QAction("Open Settings", self)
        act_open.triggered.connect(self._show_window)
        menu.addAction(act_open)

        prof_menu = menu.addMenu("Switch Profile")
        for pname in self.cfg.profiles:
            act = QAction(pname, self, checkable=True, checked=(pname == self.cfg.active_profile))
            act.triggered.connect(lambda checked=False, name=pname: self._switch_profile(name))
            prof_menu.addAction(act)

        menu.addSeparator()
        act_reconn = QAction("Force Reconnect LCD", self)
        act_reconn.triggered.connect(self.worker.request_reconnect)
        menu.addAction(act_reconn)

        self.act_pause = QAction("Pause Updates", self, checkable=True)
        self.act_pause.toggled.connect(self.worker.set_paused)
        menu.addAction(self.act_pause)

        act_logs = QAction("Open Logs Folder", self)
        act_logs.triggered.connect(lambda: os.startfile(str(LOG_DIR)))
        menu.addAction(act_logs)

        menu.addSeparator()
        act_quit = QAction("Quit", self)
        act_quit.triggered.connect(self._quit_app)
        menu.addAction(act_quit)
        self.tray.setContextMenu(menu)

    def _on_tray_activated(self, reason) -> None:
        if reason in (QSystemTrayIcon.ActivationReason.Trigger, QSystemTrayIcon.ActivationReason.DoubleClick):
            self._show_window()

    def _show_window(self) -> None:
        self.showNormal()
        self.activateWindow()
        self.raise_()

    def closeEvent(self, event) -> None:
        if not self._really_quit and self.cfg.minimize_to_tray_on_close:
            event.ignore()
            self.hide()
            self.tray.showMessage(
                "Kraken Dashboard",
                "Running quietly in the system tray. Right-click the tray icon to Quit.",
                QSystemTrayIcon.MessageIcon.Information,
                2500,
            )
            return
        self._shutdown()
        event.accept()

    def _quit_app(self) -> None:
        self._really_quit = True
        self._shutdown()
        QApplication.quit()

    def _shutdown(self) -> None:
        self._log_timer.stop()
        self.worker.stop()
        self.worker.wait(4000)
        self.tray.hide()

    # --- UI Construction ---
    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)

        left_col = QVBoxLayout()
        self.preview = CircularPreviewWidget(320)
        left_col.addWidget(self.preview, alignment=Qt.AlignmentFlag.AlignHCenter)

        self.lbl_status = QLabel("Starting...")
        self.lbl_status.setWordWrap(True)
        self.lbl_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_status.setStyleSheet("font-weight: bold; padding: 6px; border-radius: 4px; background: #222; color: #ddd;")
        left_col.addWidget(self.lbl_status)

        self.lbl_cam_warn = QLabel("")
        self.lbl_cam_warn.setWordWrap(True)
        self.lbl_cam_warn.setVisible(False)
        self.lbl_cam_warn.setStyleSheet("background: #5c2020; color: #ffd4d4; padding: 6px; border-radius: 4px;")
        left_col.addWidget(self.lbl_cam_warn)

        if not is_admin():
            lbl_adm = QLabel("Note: Not elevated (Admin). CPU temperature requires running as Administrator.")
            lbl_adm.setWordWrap(True)
            lbl_adm.setStyleSheet("background: #554218; color: #ffebad; padding: 6px; border-radius: 4px;")
            left_col.addWidget(lbl_adm)

        btn_row = QHBoxLayout()
        btn_reconn = QPushButton("Force Reconnect")
        btn_reconn.clicked.connect(self.worker.request_reconnect)
        btn_test_sleep = QPushButton("Test Sleep/Wake")
        btn_test_sleep.clicked.connect(self._simulate_sleep_wake)
        btn_row.addWidget(btn_reconn)
        btn_row.addWidget(btn_test_sleep)
        left_col.addLayout(btn_row)
        left_col.addStretch()

        root.addLayout(left_col, 0)

        tabs = QTabWidget()
        tabs.addTab(self._build_tab_general(), "Profiles & Display")
        tabs.addTab(self._build_tab_background(), "Background")
        tabs.addTab(self._build_tab_sides(), "CPU & GPU Sides")
        tabs.addTab(self._build_tab_style(), "Style & Fonts")
        tabs.addTab(self._build_tab_diagnostics(), "Sensors & Logs")
        root.addWidget(tabs, 1)

    def _build_tab_general(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)

        grp_prof = QGroupBox("Profiles")
        p_lay = QVBoxLayout(grp_prof)
        row = QHBoxLayout()
        self.cmb_profile = QComboBox()
        self.cmb_profile.currentTextChanged.connect(self._on_profile_combo_changed)
        btn_new = QPushButton("New")
        btn_dup = QPushButton("Duplicate")
        btn_del = QPushButton("Delete")
        btn_new.clicked.connect(self._new_profile)
        btn_dup.clicked.connect(self._dup_profile)
        btn_del.clicked.connect(self._del_profile)
        row.addWidget(self.cmb_profile, 1)
        row.addWidget(btn_new)
        row.addWidget(btn_dup)
        row.addWidget(btn_del)
        p_lay.addLayout(row)
        lay.addWidget(grp_prof)

        grp_disp = QGroupBox("LCD Hardware & Power")
        form = QFormLayout(grp_disp)

        b_row = QHBoxLayout()
        self.sld_bright = QSlider(Qt.Orientation.Horizontal)
        self.sld_bright.setRange(0, 100)
        self.lbl_bright = QLabel("100%")
        self.sld_bright.valueChanged.connect(lambda v: (self.lbl_bright.setText(f"{v}%"), self._apply_ui_to_config()))
        b_row.addWidget(self.sld_bright)
        b_row.addWidget(self.lbl_bright)
        form.addRow("Brightness:", b_row)

        self.cmb_orient = QComboBox()
        for deg in (0, 90, 180, 270):
            self.cmb_orient.addItem(f"{deg}°", deg)
        self.cmb_orient.currentIndexChanged.connect(self._apply_ui_to_config)
        form.addRow("Orientation:", self.cmb_orient)

        self.spn_interval = QDoubleSpinBox()
        self.spn_interval.setRange(0.6, 5.0)
        self.spn_interval.setSingleStep(0.2)
        self.spn_interval.setSuffix(" s")
        self.spn_interval.valueChanged.connect(self._apply_ui_to_config)
        form.addRow("Static Refresh:", self.spn_interval)

        self.spn_gif_interval = QDoubleSpinBox()
        self.spn_gif_interval.setRange(1.0, 10.0)
        self.spn_gif_interval.setSingleStep(0.5)
        self.spn_gif_interval.setSuffix(" s")
        self.spn_gif_interval.valueChanged.connect(self._apply_ui_to_config)
        form.addRow("GIF Min Swap Gap:", self.spn_gif_interval)

        self.chk_blank_sleep = QCheckBox("Blank / dim LCD to 0% when Windows sleeps")
        self.chk_blank_sleep.toggled.connect(self._apply_ui_to_config)
        form.addRow("", self.chk_blank_sleep)

        self.chk_min_tray = QCheckBox("Minimize to system tray when closing window")
        self.chk_min_tray.toggled.connect(self._apply_ui_to_config)
        form.addRow("", self.chk_min_tray)

        lay.addWidget(grp_disp)

        grp_auto = QGroupBox("Windows Startup")
        a_lay = QHBoxLayout(grp_auto)
        btn_inst = QPushButton("Install Auto-Start (Task Scheduler)")
        btn_inst.clicked.connect(self._run_autostart_script)
        a_lay.addWidget(btn_inst)
        lay.addWidget(grp_auto)

        lay.addStretch()
        return w

    def _build_tab_background(self) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)

        path_row = QHBoxLayout()
        self.txt_bg = QLineEdit()
        self.txt_bg.setPlaceholderText("Default gradient backdrop (or pick JPG / PNG / GIF)")
        self.txt_bg.editingFinished.connect(self._apply_ui_to_config)
        btn_browse = QPushButton("Browse...")
        btn_clear = QPushButton("Clear")
        btn_browse.clicked.connect(self._browse_bg)
        btn_clear.clicked.connect(lambda: (self.txt_bg.setText(""), self._apply_ui_to_config()))
        path_row.addWidget(self.txt_bg, 1)
        path_row.addWidget(btn_browse)
        path_row.addWidget(btn_clear)
        form.addRow("Image / GIF:", path_row)

        dim_row = QHBoxLayout()
        self.sld_dim = QSlider(Qt.Orientation.Horizontal)
        self.sld_dim.setRange(0, 85)
        self.lbl_dim = QLabel("28%")
        self.sld_dim.valueChanged.connect(lambda v: (self.lbl_dim.setText(f"{v}%"), self._apply_ui_to_config()))
        dim_row.addWidget(self.sld_dim)
        dim_row.addWidget(self.lbl_dim)
        form.addRow("Dimming:", dim_row)

        self.cmb_fit = QComboBox()
        for fit in ("cover", "contain", "stretch"):
            self.cmb_fit.addItem(fit.capitalize(), fit)
        self.cmb_fit.currentIndexChanged.connect(self._apply_ui_to_config)
        form.addRow("Fit Mode:", self.cmb_fit)

        zoom_row = QHBoxLayout()
        self.sld_scale = QSlider(Qt.Orientation.Horizontal)
        self.sld_scale.setRange(50, 200)
        self.lbl_scale = QLabel("100%")
        self.sld_scale.valueChanged.connect(lambda v: (self.lbl_scale.setText(f"{v}%"), self._apply_ui_to_config()))
        zoom_row.addWidget(self.sld_scale)
        zoom_row.addWidget(self.lbl_scale)
        form.addRow("Scale / Zoom:", zoom_row)

        self.spn_off_x = QSpinBox()
        self.spn_off_x.setRange(-320, 320)
        self.spn_off_x.setSuffix(" px")
        self.spn_off_x.valueChanged.connect(self._apply_ui_to_config)
        form.addRow("Offset X:", self.spn_off_x)

        self.spn_off_y = QSpinBox()
        self.spn_off_y.setRange(-320, 320)
        self.spn_off_y.setSuffix(" px")
        self.spn_off_y.valueChanged.connect(self._apply_ui_to_config)
        form.addRow("Offset Y:", self.spn_off_y)

        self.spn_gif_frames = QSpinBox()
        self.spn_gif_frames.setRange(12, 90)
        self.spn_gif_frames.setSingleStep(6)
        self.spn_gif_frames.setSuffix(" frames")
        self.spn_gif_frames.setToolTip("Higher = smoother long GIFs; lower = faster stat swaps")
        self.spn_gif_frames.valueChanged.connect(self._apply_ui_to_config)
        form.addRow("GIF Max Frames:", self.spn_gif_frames)

        return w

    def _build_side_group(self, title: str) -> tuple[QGroupBox, dict[str, Any]]:
        grp = QGroupBox(title)
        form = QFormLayout(grp)
        ctrls: dict[str, Any] = {}

        cmb_lmode = QComboBox()
        cmb_lmode.addItem("Auto-Detected Hardware Name", "auto")
        cmb_lmode.addItem("Custom Label", "custom")
        cmb_lmode.currentIndexChanged.connect(self._apply_ui_to_config)
        form.addRow("Label Mode:", cmb_lmode)
        ctrls["label_mode"] = cmb_lmode

        txt_label = QLineEdit()
        txt_label.setPlaceholderText("Used when Label Mode = Custom")
        txt_label.editingFinished.connect(self._apply_ui_to_config)
        form.addRow("Custom Label:", txt_label)
        ctrls["custom_label"] = txt_label

        for key, caption in (("arc_metric", "Arc Metric:"), ("row1_metric", "Row 1 Stat:"), ("row2_metric", "Row 2 Stat:")):
            cmb = QComboBox()
            for mkey, meta in METRICS.items():
                cmb.addItem(meta.label, mkey)
            cmb.currentIndexChanged.connect(self._apply_ui_to_config)
            form.addRow(caption, cmb)
            ctrls[key] = cmb

        mm_row = QHBoxLayout()
        spn_min = QDoubleSpinBox()
        spn_min.setRange(0, 10000)
        spn_min.setDecimals(0)
        spn_max = QDoubleSpinBox()
        spn_max.setRange(1, 10000)
        spn_max.setDecimals(0)
        spn_min.valueChanged.connect(self._apply_ui_to_config)
        spn_max.valueChanged.connect(self._apply_ui_to_config)
        mm_row.addWidget(QLabel("Min:"))
        mm_row.addWidget(spn_min)
        mm_row.addWidget(QLabel("Max:"))
        mm_row.addWidget(spn_max)
        form.addRow("Arc Range:", mm_row)
        ctrls["arc_min"] = spn_min
        ctrls["arc_max"] = spn_max

        chk_grad = QCheckBox("Thermal gradient bar (Cool -> Warm -> Red when hot)")
        chk_grad.toggled.connect(self._apply_ui_to_config)
        form.addRow("", chk_grad)
        ctrls["use_gradient"] = chk_grad

        c_row = QHBoxLayout()
        btn_arc = ColorButton("#00AEF0")
        btn_mid = ColorButton("#FFB800")
        btn_hot = ColorButton("#FF2424")
        btn_ico = ColorButton("#73CDFF")
        btn_arc.color_changed.connect(self._apply_ui_to_config)
        btn_mid.color_changed.connect(self._apply_ui_to_config)
        btn_hot.color_changed.connect(self._apply_ui_to_config)
        btn_ico.color_changed.connect(self._apply_ui_to_config)
        c_row.addWidget(QLabel("Cool:"))
        c_row.addWidget(btn_arc)
        c_row.addWidget(QLabel("Warm:"))
        c_row.addWidget(btn_mid)
        c_row.addWidget(QLabel("Hot:"))
        c_row.addWidget(btn_hot)
        c_row.addWidget(QLabel("Icons:"))
        c_row.addWidget(btn_ico)
        c_row.addStretch()
        form.addRow("Colors:", c_row)
        ctrls["arc_color"] = btn_arc
        ctrls["arc_mid_color"] = btn_mid
        ctrls["arc_hot_color"] = btn_hot
        ctrls["icon_color"] = btn_ico

        return grp, ctrls

    def _build_tab_sides(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        grp_l, self.left_ctrls = self._build_side_group("Left Half (CPU)")
        grp_r, self.right_ctrls = self._build_side_group("Right Half (GPU)")
        lay.addWidget(grp_l)
        lay.addWidget(grp_r)
        lay.addStretch()
        return w

    def _build_tab_style(self) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)

        font_row = QHBoxLayout()
        self.cmb_font = QComboBox()
        for fname in FONT_MAP:
            self.cmb_font.addItem(fname, fname)
        self.cmb_font.currentIndexChanged.connect(self._apply_ui_to_config)
        btn_font = QPushButton("Browse .ttf...")
        btn_font.clicked.connect(self._browse_font)
        font_row.addWidget(self.cmb_font, 1)
        font_row.addWidget(btn_font)
        form.addRow("Font Family:", font_row)

        aw_row = QHBoxLayout()
        self.sld_arc_w = QSlider(Qt.Orientation.Horizontal)
        self.sld_arc_w.setRange(10, 40)
        self.lbl_arc_w = QLabel("24 px")
        self.sld_arc_w.valueChanged.connect(lambda v: (self.lbl_arc_w.setText(f"{v} px"), self._apply_ui_to_config()))
        aw_row.addWidget(self.sld_arc_w)
        aw_row.addWidget(self.lbl_arc_w)
        form.addRow("Arc Thickness:", aw_row)

        self.chk_shadow = QCheckBox("Drop shadow behind text")
        self.chk_outline = QCheckBox("Subtle dark outline around text")
        self.chk_divider = QCheckBox("Show vertical center divider")
        self.chk_shadow.toggled.connect(self._apply_ui_to_config)
        self.chk_outline.toggled.connect(self._apply_ui_to_config)
        self.chk_divider.toggled.connect(self._apply_ui_to_config)
        form.addRow("", self.chk_shadow)
        form.addRow("", self.chk_outline)
        form.addRow("", self.chk_divider)
        return w

    def _build_tab_diagnostics(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)

        self.lbl_dev_info = QLabel("Device: waiting for connection...")
        lay.addWidget(self.lbl_dev_info)

        self.tbl_sensors = QTableWidget(0, 2)
        self.tbl_sensors.setHorizontalHeaderLabels(["Sensor", "Live Value"])
        self.tbl_sensors.horizontalHeader().setStretchLastSection(True)
        self.tbl_sensors.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tbl_sensors.setMaximumHeight(220)
        lay.addWidget(self.tbl_sensors)

        self.txt_logs = QPlainTextEdit()
        self.txt_logs.setReadOnly(True)
        self.txt_logs.setStyleSheet("font-family: Consolas; font-size: 11px;")
        lay.addWidget(self.txt_logs, 1)

        btn_open_log = QPushButton("Open Log File")
        btn_open_log.clicked.connect(lambda: os.startfile(str(LOG_FILE)) if LOG_FILE.exists() else None)
        lay.addWidget(btn_open_log)
        return w

    # --- Sync UI <-> Config ---
    @staticmethod
    def _set_combo_data(cmb: QComboBox, value: Any) -> None:
        idx = cmb.findData(value)
        if idx >= 0:
            cmb.setCurrentIndex(idx)

    def _load_profile_into_ui(self) -> None:
        self._loading_ui = True
        try:
            self.cmb_profile.clear()
            for pname in self.cfg.profiles:
                self.cmb_profile.addItem(pname)
            self.cmb_profile.setCurrentText(self.cfg.active_profile)

            prof = self.cfg.current_profile()
            self.sld_bright.setValue(int(prof.brightness))
            self.lbl_bright.setText(f"{prof.brightness}%")
            self._set_combo_data(self.cmb_orient, int(prof.orientation))
            self.spn_interval.setValue(float(prof.update_interval_sec))
            self.spn_gif_interval.setValue(float(prof.gif_update_interval_sec))
            self.chk_blank_sleep.setChecked(bool(self.cfg.blank_on_sleep))
            self.chk_min_tray.setChecked(bool(self.cfg.minimize_to_tray_on_close))

            self.txt_bg.setText(prof.bg_path)
            dim_pct = int(round(prof.bg_dim * 100))
            self.sld_dim.setValue(dim_pct)
            self.lbl_dim.setText(f"{dim_pct}%")
            self._set_combo_data(self.cmb_fit, prof.bg_fit)
            scale_pct = int(round(prof.bg_scale * 100))
            self.sld_scale.setValue(scale_pct)
            self.lbl_scale.setText(f"{scale_pct}%")
            self.spn_off_x.setValue(int(prof.bg_offset_x))
            self.spn_off_y.setValue(int(prof.bg_offset_y))
            self.spn_gif_frames.setValue(int(getattr(prof, "gif_max_frames", 60)))

            for side, ctrls in ((prof.left, self.left_ctrls), (prof.right, self.right_ctrls)):
                self._set_combo_data(ctrls["label_mode"], side.label_mode)
                ctrls["custom_label"].setText(side.custom_label)
                self._set_combo_data(ctrls["arc_metric"], side.arc_metric)
                self._set_combo_data(ctrls["row1_metric"], side.row1_metric)
                self._set_combo_data(ctrls["row2_metric"], side.row2_metric)
                ctrls["arc_min"].setValue(float(side.arc_min))
                ctrls["arc_max"].setValue(float(side.arc_max))
                ctrls["use_gradient"].setChecked(bool(side.use_gradient))
                ctrls["arc_color"].set_color(side.arc_color)
                ctrls["arc_mid_color"].set_color(side.arc_mid_color)
                ctrls["arc_hot_color"].set_color(side.arc_hot_color)
                ctrls["icon_color"].set_color(side.icon_color)

            if prof.font_family and self.cmb_font.findData(prof.font_family) < 0:
                self.cmb_font.addItem(Path(prof.font_family).stem, prof.font_family)
            self._set_combo_data(self.cmb_font, prof.font_family)

            self.sld_arc_w.setValue(int(prof.arc_width))
            self.lbl_arc_w.setText(f"{prof.arc_width} px")
            self.chk_shadow.setChecked(bool(prof.text_shadow))
            self.chk_outline.setChecked(bool(prof.text_outline))
            self.chk_divider.setChecked(bool(prof.show_divider))
        finally:
            self._loading_ui = False

    def _apply_ui_to_config(self, *_args) -> None:
        if self._loading_ui:
            return
        prof = self.cfg.current_profile()
        prof.brightness = int(self.sld_bright.value())
        prof.orientation = int(self.cmb_orient.currentData())
        prof.update_interval_sec = float(self.spn_interval.value())
        prof.gif_update_interval_sec = float(self.spn_gif_interval.value())
        self.cfg.blank_on_sleep = bool(self.chk_blank_sleep.isChecked())
        self.cfg.minimize_to_tray_on_close = bool(self.chk_min_tray.isChecked())

        prof.bg_path = self.txt_bg.text().strip()
        prof.bg_dim = float(self.sld_dim.value()) / 100.0
        prof.bg_fit = str(self.cmb_fit.currentData())
        prof.bg_scale = float(self.sld_scale.value()) / 100.0
        prof.bg_offset_x = int(self.spn_off_x.value())
        prof.bg_offset_y = int(self.spn_off_y.value())
        prof.gif_max_frames = int(self.spn_gif_frames.value())

        for side, ctrls in ((prof.left, self.left_ctrls), (prof.right, self.right_ctrls)):
            side.label_mode = str(ctrls["label_mode"].currentData())
            side.custom_label = ctrls["custom_label"].text().strip()
            side.arc_metric = str(ctrls["arc_metric"].currentData())
            side.row1_metric = str(ctrls["row1_metric"].currentData())
            side.row2_metric = str(ctrls["row2_metric"].currentData())
            side.arc_min = float(ctrls["arc_min"].value())
            side.arc_max = float(ctrls["arc_max"].value())
            side.use_gradient = bool(ctrls["use_gradient"].isChecked())
            side.arc_color = ctrls["arc_color"].color()
            side.arc_mid_color = ctrls["arc_mid_color"].color()
            side.arc_hot_color = ctrls["arc_hot_color"].color()
            side.icon_color = ctrls["icon_color"].color()

        font_data = self.cmb_font.currentData()
        prof.font_family = str(font_data) if font_data else self.cmb_font.currentText()
        prof.arc_width = int(self.sld_arc_w.value())
        prof.text_shadow = bool(self.chk_shadow.isChecked())
        prof.text_outline = bool(self.chk_outline.isChecked())
        prof.show_divider = bool(self.chk_divider.isChecked())

        save_config(self.cfg)
        self.worker.update_config(self.cfg)

    # --- Actions ---
    def _browse_bg(self) -> None:
        start_dir = str(APP_DIR / "Gifs") if (APP_DIR / "Gifs").exists() else str(Path.home())
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Background Image or Animated GIF",
            start_dir,
            "Images & GIFs (*.gif *.png *.jpg *.jpeg *.webp *.bmp);;All Files (*.*)",
        )
        if path:
            self.txt_bg.setText(path)
            self._apply_ui_to_config()

    def _browse_font(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Font File (.ttf / .otf)",
            "C:/Windows/Fonts",
            "Fonts (*.ttf *.otf);;All Files (*.*)",
        )
        if path:
            if self.cmb_font.findData(path) < 0:
                self.cmb_font.addItem(Path(path).stem, path)
            self._set_combo_data(self.cmb_font, path)
            self._apply_ui_to_config()

    def _on_profile_combo_changed(self, name: str) -> None:
        if not self._loading_ui and name and name in self.cfg.profiles:
            self._switch_profile(name)

    def _switch_profile(self, name: str) -> None:
        if name not in self.cfg.profiles:
            return
        self.cfg.active_profile = name
        save_config(self.cfg)
        self._load_profile_into_ui()
        self._rebuild_tray_menu()
        self.worker.update_config(self.cfg)

    def _new_profile(self) -> None:
        name, ok = QInputDialog.getText(self, "New Profile", "Profile name:")
        name = name.strip()
        if ok and name:
            if name in self.cfg.profiles:
                QMessageBox.warning(self, "Exists", f"Profile '{name}' already exists.")
                return
            self.cfg.profiles[name] = ProfileConfig(name=name)
            self._switch_profile(name)

    def _dup_profile(self) -> None:
        cur = self.cfg.current_profile()
        name, ok = QInputDialog.getText(self, "Duplicate Profile", "New profile name:", text=f"{cur.name} Copy")
        name = name.strip()
        if ok and name:
            if name in self.cfg.profiles:
                QMessageBox.warning(self, "Exists", f"Profile '{name}' already exists.")
                return
            dup = clone_config(self.cfg).profiles[cur.name]
            dup.name = name
            self.cfg.profiles[name] = dup
            self._switch_profile(name)

    def _del_profile(self) -> None:
        if len(self.cfg.profiles) <= 1:
            QMessageBox.information(self, "Cannot Delete", "At least one profile must remain.")
            return
        cur = self.cfg.active_profile
        if QMessageBox.question(self, "Delete Profile", f"Delete profile '{cur}'?") == QMessageBox.StandardButton.Yes:
            del self.cfg.profiles[cur]
            self.cfg.active_profile = next(iter(self.cfg.profiles))
            self._switch_profile(self.cfg.active_profile)

    def _simulate_sleep_wake(self) -> None:
        log.info("User triggered simulated sleep/wake recovery test.")
        self.worker.request_sleep()
        QTimer.singleShot(2500, lambda: self.worker.request_wake(settle_seconds=1.5))

    def _run_autostart_script(self) -> None:
        script = APP_DIR / "install_autostart.ps1"
        if not script.exists():
            QMessageBox.warning(self, "Missing Script", f"Create {script.name} first (see README).")
            return
        try:
            subprocess.Popen(["powershell", "-ExecutionPolicy", "Bypass", "-File", str(script)])
            QMessageBox.information(self, "Auto-Start", "Launched install_autostart.ps1 — check PowerShell output.")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # --- Worker Slots ---
    def _on_status(self, text: str, connected: bool) -> None:
        bg = "#1b4328" if connected else "#4d2f18"
        fg = "#c9ffd9" if connected else "#ffe0bd"
        self.lbl_status.setText(text)
        self.lbl_status.setStyleSheet(f"font-weight: bold; padding: 6px; border-radius: 4px; background: {bg}; color: {fg};")
        self.tray.setToolTip(f"Kraken Dashboard — {text}")

    def _on_device_info(self, info: dict) -> None:
        self.lbl_dev_info.setText(
            f"Model: {info['model']}  |  USB: {info['vid_pid']}  |  FW: {info['firmware']}  |  LCD: {info['resolution']}"
        )

    def _on_cam_warnings(self, warnings: list) -> None:
        if warnings:
            self.lbl_cam_warn.setText("NZXT CAM Conflict:\n" + "\n".join(warnings))
            self.lbl_cam_warn.setVisible(True)
        else:
            self.lbl_cam_warn.setVisible(False)

    def _on_stats(self, snap: dict) -> None:
        rows = [
            ("CPU Name", snap.get("cpu_name", "")),
            ("CPU Temp Sensor", snap.get("cpu_temp_sensor", "")),
            ("GPU Name", snap.get("gpu_name", "")),
        ]
        for key, meta in METRICS.items():
            if key == "none":
                continue
            rows.append((meta.label, format_metric_value(key, snap.get(key))))

        self.tbl_sensors.setRowCount(len(rows))
        for i, (k, v) in enumerate(rows):
            self.tbl_sensors.setItem(i, 0, QTableWidgetItem(str(k)))
            self.tbl_sensors.setItem(i, 1, QTableWidgetItem(str(v)))

    def _refresh_log_tail(self) -> None:
        self.txt_logs.setPlainText("\n".join(self.log_handler.lines))
        sb = self.txt_logs.verticalScrollBar()
        sb.setValue(sb.maximum())


def main() -> None:
    parser = argparse.ArgumentParser(description="Standalone NZXT Kraken Elite LCD Dashboard")
    parser.add_argument("--minimized", action="store_true", help="Start hidden in the system tray")
    args = parser.parse_args()

    log_handler = setup_logging()
    mutex = acquire_single_instance_mutex()
    if mutex is None:
        log.warning("Another instance of Kraken Elite Dashboard is already running.")
        sys.exit(0)

    log.info("Starting Kraken Elite Standalone Dashboard (admin=%s, minimized=%s)", is_admin(), args.minimized)
    cfg = load_config()

    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setStyle("Fusion")

    pal = app.palette()
    pal.setColor(pal.ColorRole.Window, QColor(28, 30, 36))
    pal.setColor(pal.ColorRole.WindowText, QColor(235, 238, 245))
    pal.setColor(pal.ColorRole.Base, QColor(20, 22, 27))
    pal.setColor(pal.ColorRole.AlternateBase, QColor(34, 37, 44))
    pal.setColor(pal.ColorRole.Text, QColor(235, 238, 245))
    pal.setColor(pal.ColorRole.Button, QColor(44, 48, 58))
    pal.setColor(pal.ColorRole.ButtonText, QColor(235, 238, 245))
    pal.setColor(pal.ColorRole.Highlight, QColor(0, 145, 215))
    app.setPalette(pal)

    win = MainWindow(cfg, log_handler, start_minimized=args.minimized)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
