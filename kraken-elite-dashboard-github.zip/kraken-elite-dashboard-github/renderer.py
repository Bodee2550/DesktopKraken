from __future__ import annotations

import io
import logging
import math
import time
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageEnhance, ImageFont, ImageSequence

from config import ProfileConfig, SideConfig
from kraken_driver import LCD_HEIGHT, LCD_WIDTH, MAX_GIF_BYTES
from sensors import METRICS, format_metric_value

log = logging.getLogger("kraken.render")

WHITE = (255, 255, 255, 255)
TRACK_COLOR = (38, 41, 48, 220)

WIN_FONTS = Path("C:/Windows/Fonts")
USER_FONTS = Path.home() / "AppData/Local/Microsoft/Windows/Fonts"

FONT_MAP: dict[str, list[str]] = {
    "Bahnschrift": ["bahnschrift.ttf"],
    "Segoe UI": ["segoeui.ttf"],
    "Segoe UI Bold": ["segoeuib.ttf"],
    "Consolas": ["consola.ttf"],
    "Consolas Bold": ["consolab.ttf"],
    "Arial": ["arial.ttf"],
    "Arial Black": ["ariblk.ttf"],
    "Calibri Bold": ["calibrib.ttf"],
    "Impact": ["impact.ttf"],
    "Georgia Bold": ["georgiab.ttf"],
    "Trebuchet Bold": ["trebucbd.ttf"],
    "Verdana Bold": ["verdanab.ttf"],
}


def hex_to_rgba(hex_str: str, alpha: int = 255) -> tuple[int, int, int, int]:
    cleaned = hex_str.strip().lstrip("#")
    if len(cleaned) == 6:
        try:
            r = int(cleaned[0:2], 16)
            g = int(cleaned[2:4], 16)
            b = int(cleaned[4:6], 16)
            return (r, g, b, alpha)
        except ValueError:
            pass
    return (0, 174, 240, alpha)


def lerp_rgba(
    c1: tuple[int, int, int, int], c2: tuple[int, int, int, int], t: float
) -> tuple[int, int, int, int]:
    t = max(0.0, min(1.0, t))
    return (
        int(round(c1[0] + (c2[0] - c1[0]) * t)),
        int(round(c1[1] + (c2[1] - c1[1]) * t)),
        int(round(c1[2] + (c2[2] - c1[2]) * t)),
        int(round(c1[3] + (c2[3] - c1[3]) * t)),
    )


def sample_thermal_gradient(
    t: float,
    cool: tuple[int, int, int, int],
    mid: tuple[int, int, int, int],
    hot: tuple[int, int, int, int],
    hot_start: float = 0.80,
) -> tuple[int, int, int, int]:
    """Smooth 3-stop thermal ramp: Cool (0%) -> Warm (50%) -> Red (80%..100%)."""
    t = max(0.0, min(1.0, t))
    mid_pos = hot_start * 0.625  # 0.50 when hot_start=0.80
    if t <= mid_pos:
        return lerp_rgba(cool, mid, t / max(0.001, mid_pos))
    if t <= hot_start:
        return lerp_rgba(mid, hot, (t - mid_pos) / max(0.001, hot_start - mid_pos))
    return hot


def apply_orientation(img: Image.Image, orientation_deg: int) -> Image.Image:
    """Lossless clockwise rotation for 640x640 LCD frames (0 / 90 / 180 / 270)."""
    deg = (int(orientation_deg) // 90) % 4 * 90
    if deg == 90:
        return img.transpose(Image.Transpose.ROTATE_270)
    if deg == 180:
        return img.transpose(Image.Transpose.ROTATE_180)
    if deg == 270:
        return img.transpose(Image.Transpose.ROTATE_90)
    return img


def _resolve_font_path(family: str) -> Path | None:
    direct = Path(family)
    if direct.is_file():
        return direct

    filenames = FONT_MAP.get(family, [family])
    for fname in filenames:
        for folder in (WIN_FONTS, USER_FONTS):
            candidate = folder / fname
            if candidate.is_file():
                return candidate

    target = family.lower().replace(" ", "")
    for folder in (USER_FONTS, WIN_FONTS):
        if not folder.exists():
            continue
        for ext in ("*.ttf", "*.otf"):
            for f in folder.glob(ext):
                if f.stem.lower().replace(" ", "") == target:
                    return f
    return None


def _build_circle_mask(size: int) -> Image.Image:
    mask = Image.new("L", (size, size), 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse([0, 0, size - 1, size - 1], fill=255)
    return mask


def _fit_frame(
    src: Image.Image,
    target_size: int,
    fit: str,
    scale: float,
    offset_x: int,
    offset_y: int,
    dim: float,
    circle_mask: Image.Image | None = None,
) -> Image.Image:
    src_rgb = src.convert("RGB")
    sw, sh = src_rgb.size
    zoom = max(0.5, min(2.5, float(scale)))

    if fit == "stretch":
        nw = max(1, int(target_size * zoom))
        nh = max(1, int(target_size * zoom))
        resized = src_rgb.resize((nw, nh), Image.Resampling.LANCZOS)
    elif fit == "contain":
        ratio = min(target_size / sw, target_size / sh) * zoom
        nw = max(1, int(sw * ratio))
        nh = max(1, int(sh * ratio))
        resized = src_rgb.resize((nw, nh), Image.Resampling.LANCZOS)
    else:  # "cover"
        ratio = max(target_size / sw, target_size / sh) * zoom
        nw = max(1, int(sw * ratio))
        nh = max(1, int(sh * ratio))
        resized = src_rgb.resize((nw, nh), Image.Resampling.LANCZOS)

    canvas = Image.new("RGB", (target_size, target_size), (0, 0, 0))
    scale_mult = target_size / LCD_WIDTH
    paste_x = (target_size - resized.width) // 2 + int(offset_x * scale_mult)
    paste_y = (target_size - resized.height) // 2 + int(offset_y * scale_mult)
    canvas.paste(resized, (paste_x, paste_y))

    if dim > 0.0:
        canvas = ImageEnhance.Brightness(canvas).enhance(max(0.05, 1.0 - dim))

    if circle_mask is not None:
        masked = Image.new("RGB", (target_size, target_size), (0, 0, 0))
        masked.paste(canvas, (0, 0), circle_mask)
        canvas = masked

    return canvas.convert("RGBA")


def _default_backdrop(target_size: int, dim: float) -> Image.Image:
    bg = Image.new("RGB", (target_size, target_size), (10, 18, 32))
    d = ImageDraw.Draw(bg)
    step = max(2, target_size // 160)
    for y in range(0, target_size, step):
        t = y / target_size
        r = int(10 + 20 * (1 - abs(t - 0.5) * 2))
        g = int(18 + 28 * (1 - abs(t - 0.5) * 2))
        b = int(34 + 46 * (1 - abs(t - 0.45) * 2))
        d.rectangle([0, y, target_size, y + step], fill=(r, g, b))
    if dim > 0.0:
        bg = ImageEnhance.Brightness(bg).enhance(max(0.05, 1.0 - dim))
    return bg.convert("RGBA")


class DualInfoRenderer:
    """2x supersampled Dual Info renderer with thermal gradient bars and high-FPS GIF baking."""

    def __init__(self) -> None:
        self.scale = 2
        self.hi_size = LCD_WIDTH * self.scale
        self._circle_mask_640 = _build_circle_mask(LCD_WIDTH)
        self._font_cache: dict[tuple[str, int], ImageFont.FreeTypeFont | ImageFont.ImageFont] = {}
        self._grad_cache: dict[tuple, Image.Image] = {}
        self._last_logged_font: str | None = None

        self._bg_cache_key: tuple | None = None
        self._static_bg_640: Image.Image = _default_backdrop(LCD_WIDTH, 0.28)
        self._gif_frames_640: list[Image.Image] = []
        self._gif_durations_ms: list[int] = []
        self._gif_cum_ms: list[int] = []
        self._gif_total_ms: int = 0

        self._overlay_cache_sig: tuple | None = None
        self._overlay_cache_640: Image.Image | None = None

    @property
    def is_animated_gif(self) -> bool:
        return len(self._gif_frames_640) > 1

    @property
    def gif_frame_count(self) -> int:
        return len(self._gif_frames_640)

    def gif_frame_duration_ms(self, idx: int) -> int:
        if not self._gif_durations_ms:
            return 40
        return self._gif_durations_ms[idx % len(self._gif_durations_ms)]

    def gif_frame_at_elapsed(self, elapsed_sec: float) -> int:
        """Map elapsed seconds to the exact GIF frame index for smooth preview & phase-locked swaps."""
        if not self._gif_cum_ms or self._gif_total_ms <= 0:
            return 0
        pos_ms = int(elapsed_sec * 1000.0) % self._gif_total_ms
        for i, end_ms in enumerate(self._gif_cum_ms):
            if pos_ms < end_ms:
                return i
        return len(self._gif_cum_ms) - 1

    def _get_font(self, family: str, px: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
        key = (family, px)
        if key not in self._font_cache:
            resolved = _resolve_font_path(family)
            if self._last_logged_font != family:
                self._last_logged_font = family
                if resolved:
                    log.info("Font switched to '%s' (%s)", family, resolved)
                else:
                    log.warning("Font '%s' not found; falling back to default system font.", family)

            loaded = None
            candidates = ([resolved] if resolved else []) + [
                WIN_FONTS / "bahnschrift.ttf",
                WIN_FONTS / "segoeui.ttf",
                WIN_FONTS / "arial.ttf",
            ]
            for path in candidates:
                if path and path.is_file():
                    try:
                        loaded = ImageFont.truetype(str(path), px)
                        break
                    except Exception:
                        continue
            self._font_cache[key] = loaded or ImageFont.load_default()
        return self._font_cache[key]

    def _get_arc_gradient(self, is_left: bool, side: SideConfig) -> Image.Image:
        """Build & cache a smooth angular thermal gradient image at 2x supersampling."""
        key = (is_left, side.arc_color, side.arc_mid_color, side.arc_hot_color)
        if key in self._grad_cache:
            return self._grad_cache[key]

        cool = hex_to_rgba(side.arc_color)
        mid = hex_to_rgba(side.arc_mid_color)
        hot = hex_to_rgba(side.arc_hot_color)

        gsize = 320
        gimg = Image.new("RGBA", (gsize, gsize), cool)
        gd = ImageDraw.Draw(gimg)
        box = [-20, -20, gsize + 20, gsize + 20]

        steps = 110
        if is_left:
            gd.pieslice(box, start=110, end=126, fill=cool)
            for i in range(steps):
                t = i / float(steps - 1)
                col = sample_thermal_gradient(t, cool, mid, hot, hot_start=0.80)
                a0 = 125.0 + (110.0 * i / steps)
                a1 = 125.0 + (110.0 * (i + 1.5) / steps)
                gd.pieslice(box, start=a0, end=a1, fill=col)
            gd.pieslice(box, start=234, end=250, fill=hot)
        else:
            gd.pieslice(box, start=54, end=70, fill=cool)
            for i in range(steps):
                t = i / float(steps - 1)
                col = sample_thermal_gradient(t, cool, mid, hot, hot_start=0.80)
                a_hi = (55.0 - (110.0 * (i + 1.5) / steps)) % 360.0
                a_lo = (55.0 - (110.0 * i / steps)) % 360.0
                gd.pieslice(box, start=a_hi, end=a_lo, fill=col)
            gd.pieslice(box, start=290, end=306, fill=hot)

        smooth = gimg.resize((self.hi_size, self.hi_size), Image.Resampling.BILINEAR)
        if len(self._grad_cache) > 12:
            self._grad_cache.clear()
        self._grad_cache[key] = smooth
        return smooth

    def ensure_background(self, profile: ProfileConfig) -> None:
        p = Path(profile.bg_path) if profile.bg_path else None
        mtime = p.stat().st_mtime if (p and p.exists()) else 0.0
        max_frames = max(12, min(90, int(getattr(profile, "gif_max_frames", 60))))
        cache_key = (
            profile.bg_path,
            mtime,
            round(profile.bg_dim, 3),
            profile.bg_fit,
            round(profile.bg_scale, 3),
            int(profile.bg_offset_x),
            int(profile.bg_offset_y),
            max_frames,
        )
        if cache_key == self._bg_cache_key:
            return

        self._gif_frames_640 = []
        self._gif_durations_ms = []
        self._gif_cum_ms = []
        self._gif_total_ms = 0

        if p is None or not p.exists():
            self._static_bg_640 = _default_backdrop(LCD_WIDTH, profile.bg_dim)
            self._bg_cache_key = cache_key
            return

        try:
            with Image.open(p) as im:
                is_animated = bool(getattr(im, "is_animated", False) and getattr(im, "n_frames", 1) > 1)
                if is_animated:
                    raw_frames: list[Image.Image] = []
                    raw_durations: list[int] = []
                    for frame in ImageSequence.Iterator(im):
                        raw_d = frame.info.get("duration", im.info.get("duration", 40))
                        dur = int(raw_d) if (raw_d and int(raw_d) > 0) else 40
                        raw_durations.append(max(30, dur))
                        raw_frames.append(frame.convert("RGBA"))

                    total = len(raw_frames)
                    if total > max_frames:
                        step = total / max_frames
                        indices = [int(i * step) for i in range(max_frames)]
                        sampled_frames = [raw_frames[i] for i in indices]
                        sampled_durations = [
                            max(30, int(round(raw_durations[i] * step / 10.0) * 10))
                            for i in indices
                        ]
                    else:
                        sampled_frames = raw_frames
                        sampled_durations = [max(30, int(round(d / 10.0) * 10)) for d in raw_durations]

                    self._gif_frames_640 = [
                        _fit_frame(
                            fr,
                            LCD_WIDTH,
                            profile.bg_fit,
                            profile.bg_scale,
                            profile.bg_offset_x,
                            profile.bg_offset_y,
                            profile.bg_dim,
                            circle_mask=self._circle_mask_640,
                        )
                        for fr in sampled_frames
                    ]
                    self._gif_durations_ms = sampled_durations
                    acc = 0
                    for d in sampled_durations:
                        acc += d
                        self._gif_cum_ms.append(acc)
                    self._gif_total_ms = acc
                    self._static_bg_640 = self._gif_frames_640[0]
                    avg_fps = (1000.0 * len(sampled_durations) / acc) if acc > 0 else 0.0
                    log.info(
                        "Loaded animated GIF '%s': %d/%d frames (%.1f FPS, loop %.2fs)",
                        p.name,
                        len(self._gif_frames_640),
                        total,
                        avg_fps,
                        acc / 1000.0,
                    )
                else:
                    self._static_bg_640 = _fit_frame(
                        im,
                        LCD_WIDTH,
                        profile.bg_fit,
                        profile.bg_scale,
                        profile.bg_offset_x,
                        profile.bg_offset_y,
                        profile.bg_dim,
                    )
                    log.info("Loaded static background '%s'", p.name)
        except Exception as e:
            log.error("Failed to load background '%s': %s", p, e)
            self._static_bg_640 = _default_backdrop(LCD_WIDTH, profile.bg_dim)

        self._bg_cache_key = cache_key

    def state_signature(self, profile: ProfileConfig, stats: dict[str, Any]) -> tuple:
        def side_sig(side: SideConfig, auto_name: str) -> tuple:
            label = side.custom_label.strip() if side.label_mode == "custom" and side.custom_label.strip() else auto_name
            arc_val = stats.get(side.arc_metric)
            arc_pct = int(round(self._calc_arc_fraction(side, arc_val) * 100))
            r1 = format_metric_value(side.row1_metric, stats.get(side.row1_metric))
            r2 = format_metric_value(side.row2_metric, stats.get(side.row2_metric))
            return (
                label,
                side.arc_metric,
                arc_pct,
                side.row1_metric,
                r1,
                side.row2_metric,
                r2,
                side.arc_color,
                side.use_gradient,
                side.arc_mid_color,
                side.arc_hot_color,
                side.icon_color,
            )

        return (
            self._bg_cache_key,
            int(profile.orientation),
            profile.arc_width,
            profile.font_family,
            profile.text_shadow,
            profile.text_outline,
            profile.show_divider,
            side_sig(profile.left, stats.get("cpu_name", "CPU")),
            side_sig(profile.right, stats.get("gpu_name", "GPU")),
        )

    @staticmethod
    def _calc_arc_fraction(side: SideConfig, val: float | None) -> float:
        if side.arc_metric == "none" or val is None:
            return 0.0
        span = max(1.0, float(side.arc_max) - float(side.arc_min))
        frac = (float(val) - float(side.arc_min)) / span
        return max(0.03, min(1.0, frac))

    def _draw_rounded_arc_solid(
        self,
        draw: ImageDraw.ImageDraw,
        pad: int,
        width: int,
        start_deg: float,
        end_deg: float,
        color: tuple[int, int, int, int],
    ) -> None:
        box = [pad, pad, self.hi_size - pad, self.hi_size - pad]
        draw.arc(box, start=start_deg, end=end_deg, fill=color, width=width)
        cx = self.hi_size / 2.0
        cy = self.hi_size / 2.0
        r_mid = (self.hi_size - 2 * pad) / 2.0 - width / 2.0
        cap_r = width / 2.0
        for deg in (start_deg, end_deg):
            rad = math.radians(deg)
            px = cx + r_mid * math.cos(rad)
            py = cy + r_mid * math.sin(rad)
            draw.ellipse([px - cap_r, py - cap_r, px + cap_r, py + cap_r], fill=color)

    def _draw_rounded_arc_gradient(
        self,
        overlay: Image.Image,
        is_left: bool,
        side: SideConfig,
        pad: int,
        width: int,
        start_deg: float,
        end_deg: float,
    ) -> None:
        mask = Image.new("L", (self.hi_size, self.hi_size), 0)
        md = ImageDraw.Draw(mask)
        box = [pad, pad, self.hi_size - pad, self.hi_size - pad]
        md.arc(box, start=start_deg, end=end_deg, fill=255, width=width)
        cx = self.hi_size / 2.0
        cy = self.hi_size / 2.0
        r_mid = (self.hi_size - 2 * pad) / 2.0 - width / 2.0
        cap_r = width / 2.0
        for deg in (start_deg, end_deg):
            rad = math.radians(deg)
            px = cx + r_mid * math.cos(rad)
            py = cy + r_mid * math.sin(rad)
            md.ellipse([px - cap_r, py - cap_r, px + cap_r, py + cap_r], fill=255)

        grad_img = self._get_arc_gradient(is_left, side)
        overlay.paste(grad_img, (0, 0), mask)

    def _draw_cpu_chip(self, draw: ImageDraw.ImageDraw, cx: int, cy: int) -> None:
        s = self.scale
        r, lw, ir, pin = 17 * s, 4 * s, 7 * s, 7 * s
        draw.rounded_rectangle([cx - r, cy - r, cx + r, cy + r], radius=4 * s, outline=WHITE, width=lw)
        draw.rounded_rectangle([cx - ir, cy - ir, cx + ir, cy + ir], radius=2 * s, outline=WHITE, width=lw)
        for off in (-9 * s, 0, 9 * s):
            draw.line([(cx + off, cy - r - pin), (cx + off, cy - r)], fill=WHITE, width=lw)
            draw.line([(cx + off, cy + r), (cx + off, cy + r + pin)], fill=WHITE, width=lw)
            draw.line([(cx - r - pin, cy + off), (cx - r, cy + off)], fill=WHITE, width=lw)
            draw.line([(cx + r, cy + off), (cx + r + pin, cy + off)], fill=WHITE, width=lw)

    def _draw_gpu_chip(self, draw: ImageDraw.ImageDraw, cx: int, cy: int) -> None:
        s = self.scale
        r, lw, br, bl, pin = 17 * s, 4 * s, 9 * s, 5 * s, 7 * s
        draw.rounded_rectangle([cx - r, cy - r, cx + r, cy + r], radius=4 * s, outline=WHITE, width=lw)
        for sx in (-1, 1):
            for sy in (-1, 1):
                x0, y0 = cx + sx * br, cy + sy * br
                draw.line([(x0, y0), (x0 - sx * bl, y0)], fill=WHITE, width=lw)
                draw.line([(x0, y0), (x0, y0 - sy * bl)], fill=WHITE, width=lw)
        for off in (-9 * s, 0, 9 * s):
            draw.line([(cx + off, cy - r - pin), (cx + off, cy - r)], fill=WHITE, width=lw)
            draw.line([(cx + off, cy + r), (cx + off, cy + r + pin)], fill=WHITE, width=lw)
            draw.line([(cx - r - pin, cy + off), (cx - r, cy + off)], fill=WHITE, width=lw)
            draw.line([(cx + r, cy + off), (cx + r + pin, cy + off)], fill=WHITE, width=lw)

    def _draw_metric_icon(
        self, draw: ImageDraw.ImageDraw, icon_type: str, cx: int, cy: int, color: tuple[int, int, int, int]
    ) -> None:
        s = self.scale
        lw = 4 * s
        if icon_type == "thermometer":
            sw = 5 * s
            draw.rounded_rectangle([cx - sw, cy - 22 * s, cx + sw, cy + 6 * s], radius=sw, outline=color, width=lw)
            br = 10 * s
            draw.ellipse([cx - br, cy + 1 * s, cx + br, cy + 1 * s + 2 * br], fill=(12, 16, 24, 185), outline=color, width=lw)
            draw.ellipse([cx - 4 * s, cy + 7 * s, cx + 4 * s, cy + 15 * s], fill=color)
            draw.line([(cx, cy - 6 * s), (cx, cy + 9 * s)], fill=color, width=3 * s)
        elif icon_type == "pulse":
            pts = [
                (cx - 20 * s, cy),
                (cx - 10 * s, cy),
                (cx - 5 * s, cy - 15 * s),
                (cx + 2 * s, cy + 15 * s),
                (cx + 9 * s, cy - 7 * s),
                (cx + 13 * s, cy),
                (cx + 20 * s, cy),
            ]
            draw.line(pts, fill=color, width=lw, joint="curve")
        elif icon_type == "power":
            pts = [
                (cx + 4 * s, cy - 19 * s),
                (cx - 10 * s, cy + 2 * s),
                (cx + 1 * s, cy + 2 * s),
                (cx - 4 * s, cy + 19 * s),
                (cx + 11 * s, cy - 3 * s),
                (cx, cy - 3 * s),
                (cx + 4 * s, cy - 19 * s),
            ]
            draw.polygon(pts, fill=color)
        elif icon_type == "clock":
            r = 16 * s
            draw.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=lw)
            draw.line([(cx, cy), (cx, cy - 10 * s)], fill=color, width=3 * s)
            draw.line([(cx, cy), (cx + 8 * s, cy + 4 * s)], fill=color, width=3 * s)
        elif icon_type == "memory":
            draw.rounded_rectangle([cx - 16 * s, cy - 12 * s, cx + 16 * s, cy + 12 * s], radius=3 * s, outline=color, width=lw)
            for dx in (-8 * s, 0, 8 * s):
                draw.line([(cx + dx, cy - 5 * s), (cx + dx, cy + 5 * s)], fill=color, width=3 * s)
        elif icon_type == "droplet":
            pts = [(cx, cy - 18 * s), (cx - 12 * s, cy + 4 * s), (cx + 12 * s, cy + 4 * s)]
            draw.polygon(pts, fill=color)
            draw.ellipse([cx - 12 * s, cy - 6 * s, cx + 12 * s, cy + 18 * s], fill=color)

    def _draw_text(
        self,
        draw: ImageDraw.ImageDraw,
        xy: tuple[int, int],
        text: str,
        font: ImageFont.FreeTypeFont | ImageFont.ImageFont,
        profile: ProfileConfig,
        anchor: str = "mm",
    ) -> None:
        if not text:
            return
        s = self.scale
        x, y = xy
        if profile.text_shadow:
            draw.text((x + 2 * s, y + 3 * s), text, fill=(0, 0, 0, 215), font=font, anchor=anchor)
        draw.text(
            (x, y),
            text,
            fill=WHITE,
            font=font,
            anchor=anchor,
            stroke_width=(1 * s if profile.text_outline else 0),
            stroke_fill=(0, 0, 0, 155),
        )

    def _draw_fitted_text(
        self,
        draw: ImageDraw.ImageDraw,
        xy: tuple[int, int],
        text: str,
        max_w: int,
        base_pt: int,
        min_pt: int,
        profile: ProfileConfig,
        anchor: str = "mm",
    ) -> None:
        s = self.scale
        chosen = self._get_font(profile.font_family, base_pt * s)
        for pt in range(base_pt, min_pt - 1, -1):
            candidate = self._get_font(profile.font_family, pt * s)
            bbox = draw.textbbox((0, 0), text, font=candidate)
            if (bbox[2] - bbox[0]) <= max_w:
                chosen = candidate
                break
        self._draw_text(draw, xy, text, chosen, profile, anchor=anchor)

    def render_overlay_640(self, profile: ProfileConfig, stats: dict[str, Any]) -> Image.Image:
        sig = self.state_signature(profile, stats)
        if sig == self._overlay_cache_sig and self._overlay_cache_640 is not None:
            return self._overlay_cache_640

        s = self.scale
        overlay = Image.new("RGBA", (self.hi_size, self.hi_size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)

        pad = 28 * s
        arc_w = max(8, min(42, int(profile.arc_width))) * s

        l_frac = 0.0
        if profile.left.arc_metric != "none":
            self._draw_rounded_arc_solid(draw, pad, arc_w, 125, 235, TRACK_COLOR)
            l_frac = self._calc_arc_fraction(profile.left, stats.get(profile.left.arc_metric))
            if l_frac > 0:
                if profile.left.use_gradient:
                    self._draw_rounded_arc_gradient(
                        overlay, True, profile.left, pad, arc_w, 125, 125 + 110 * l_frac
                    )
                else:
                    self._draw_rounded_arc_solid(
                        draw, pad, arc_w, 125, 125 + 110 * l_frac, hex_to_rgba(profile.left.arc_color)
                    )

        r_frac = 0.0
        if profile.right.arc_metric != "none":
            self._draw_rounded_arc_solid(draw, pad, arc_w, 305, 55, TRACK_COLOR)
            r_frac = self._calc_arc_fraction(profile.right, stats.get(profile.right.arc_metric))
            if r_frac > 0:
                r_start = (55 - 110 * r_frac) % 360
                if profile.right.use_gradient:
                    self._draw_rounded_arc_gradient(
                        overlay, False, profile.right, pad, arc_w, r_start, 55
                    )
                else:
                    self._draw_rounded_arc_solid(
                        draw, pad, arc_w, r_start, 55, hex_to_rgba(profile.right.arc_color)
                    )

        draw = ImageDraw.Draw(overlay)

        cx = self.hi_size // 2
        if profile.show_divider:
            draw.line([(cx, 252 * s), (cx, 448 * s)], fill=(255, 255, 255, 225), width=2 * s)

        columns = [
            (profile.left, 200 * s, 146 * s, 182 * s, stats.get("cpu_name", "CPU"), True, l_frac),
            (profile.right, 440 * s, 392 * s, 428 * s, stats.get("gpu_name", "GPU"), False, r_frac),
        ]

        for side, col_x, icon_x, val_x, auto_name, is_left, arc_frac in columns:
            if is_left:
                self._draw_cpu_chip(draw, col_x, 198 * s)
            else:
                self._draw_gpu_chip(draw, col_x, 198 * s)

            label = (
                side.custom_label.strip()
                if (side.label_mode == "custom" and side.custom_label.strip())
                else auto_name
            )
            self._draw_fitted_text(draw, (col_x, 268 * s), label, 202 * s, 25, 15, profile, anchor="mm")

            icon_rgba = hex_to_rgba(side.icon_color)
            if side.use_gradient and arc_frac >= 0.72:
                hot_blend = (arc_frac - 0.72) / 0.18
                icon_rgba = lerp_rgba(icon_rgba, hex_to_rgba(side.arc_hot_color), hot_blend)

            if side.row1_metric != "none":
                meta1 = METRICS.get(side.row1_metric)
                val1_txt = format_metric_value(side.row1_metric, stats.get(side.row1_metric))
                if meta1:
                    self._draw_metric_icon(draw, meta1.icon, icon_x, 342 * s, icon_rgba)
                self._draw_fitted_text(draw, (val_x, 345 * s), val1_txt, 130 * s, 45, 24, profile, anchor="lm")

            if side.row2_metric != "none":
                meta2 = METRICS.get(side.row2_metric)
                val2_txt = format_metric_value(side.row2_metric, stats.get(side.row2_metric))
                if meta2:
                    self._draw_metric_icon(draw, meta2.icon, icon_x, 418 * s, icon_rgba)
                self._draw_fitted_text(draw, (val_x, 420 * s), val2_txt, 130 * s, 45, 24, profile, anchor="lm")

        out = overlay.resize((LCD_WIDTH, LCD_HEIGHT), Image.Resampling.LANCZOS)
        self._overlay_cache_sig = sig
        self._overlay_cache_640 = out
        return out

    def render_frame_rgba(self, profile: ProfileConfig, stats: dict[str, Any], gif_idx: int = 0) -> Image.Image:
        self.ensure_background(profile)
        bg = (
            self._gif_frames_640[gif_idx % len(self._gif_frames_640)]
            if self.is_animated_gif
            else self._static_bg_640
        )
        overlay = self.render_overlay_640(profile, stats)
        composed = Image.alpha_composite(bg, overlay)
        return apply_orientation(composed, profile.orientation)

    def render_rgbx(self, profile: ProfileConfig, stats: dict[str, Any]) -> tuple[bytes, Image.Image]:
        rgba = self.render_frame_rgba(profile, stats, gif_idx=0)
        return rgba.convert("RGB").tobytes("raw", "RGBX"), rgba

    def _build_shared_palette(self, frames_rgb: list[Image.Image], profile: ProfileConfig, colors: int) -> Image.Image:
        """Build a shared global palette from sampled GIF frames + explicit UI accent swatches."""
        sample_count = min(6, len(frames_rgb))
        step = max(1, len(frames_rgb) // sample_count)
        samples = [frames_rgb[min(i * step, len(frames_rgb) - 1)] for i in range(sample_count)]

        tile = 160
        cols = 3
        rows = math.ceil(len(samples) / cols)
        swatch_h = 24
        sheet = Image.new("RGB", (cols * tile, rows * tile + swatch_h), (0, 0, 0))
        for idx, fr in enumerate(samples):
            thumb = fr.resize((tile, tile), Image.Resampling.BILINEAR)
            sheet.paste(thumb, ((idx % cols) * tile, (idx // cols) * tile))

        sd = ImageDraw.Draw(sheet)
        swatches = [
            (255, 255, 255),
            (0, 0, 0),
            (38, 41, 48),
            hex_to_rgba(profile.left.arc_color)[:3],
            hex_to_rgba(profile.left.arc_mid_color)[:3],
            hex_to_rgba(profile.left.arc_hot_color)[:3],
            hex_to_rgba(profile.left.icon_color)[:3],
            hex_to_rgba(profile.right.arc_color)[:3],
            hex_to_rgba(profile.right.arc_mid_color)[:3],
            hex_to_rgba(profile.right.arc_hot_color)[:3],
            hex_to_rgba(profile.right.icon_color)[:3],
        ]
        sw_w = max(1, sheet.width // len(swatches))
        y0 = rows * tile
        for i, rgb in enumerate(swatches):
            sd.rectangle([i * sw_w, y0, (i + 1) * sw_w, y0 + swatch_h], fill=rgb)

        return sheet.quantize(colors=colors, method=Image.Quantize.FASTOCTREE, dither=Image.Dither.NONE)

    def render_gif(
        self,
        profile: ProfileConfig,
        stats: dict[str, Any],
        start_frame: int = 0,
    ) -> tuple[bytes, Image.Image, dict[str, Any]]:
        """Composite live stats onto pre-decoded GIF frames with shared palette + delta optimization."""
        t0 = time.perf_counter()
        self.ensure_background(profile)
        overlay = self.render_overlay_640(profile, stats)

        n = len(self._gif_frames_640)
        shift = start_frame % n if n > 0 else 0
        ordered_bgs = self._gif_frames_640[shift:] + self._gif_frames_640[:shift]
        ordered_durs = self._gif_durations_ms[shift:] + self._gif_durations_ms[:shift]

        composed_rgba = [
            apply_orientation(Image.alpha_composite(bg, overlay), profile.orientation)
            for bg in ordered_bgs
        ]
        composed_rgb = [fr.convert("RGB") for fr in composed_rgba]
        preview_rgba = composed_rgba[0]

        attempts: list[tuple[list[Image.Image], list[int], int]] = [
            (composed_rgb, ordered_durs, 128),
            (composed_rgb, ordered_durs, 80),
            (composed_rgb, ordered_durs, 48),
        ]
        if n > 24:
            idx_23 = [i for i in range(n) if i % 3 != 2]
            durs_23 = [max(30, int(round(ordered_durs[i] * 1.5 / 10.0) * 10)) for i in idx_23]
            attempts.append(([composed_rgb[i] for i in idx_23], durs_23, 64))
            attempts.append((composed_rgb[::2], [max(30, d * 2) for d in ordered_durs[::2]], 48))

        last_bytes = b""
        chosen_frames = len(composed_rgb)
        chosen_durs = ordered_durs
        chosen_colors = 128

        for frames_src, durations, colors in attempts:
            pal = self._build_shared_palette(frames_src, profile, colors)
            quantized = [fr.quantize(palette=pal, dither=Image.Dither.NONE) for fr in frames_src]
            buf = io.BytesIO()
            quantized[0].save(
                buf,
                format="GIF",
                save_all=True,
                append_images=quantized[1:],
                duration=durations,
                loop=0,
                optimize=True,
            )
            last_bytes = buf.getvalue()
            chosen_frames = len(frames_src)
            chosen_durs = durations
            chosen_colors = colors
            if len(last_bytes) <= MAX_GIF_BYTES:
                break

        total_ms = sum(chosen_durs) or 1
        meta = {
            "frames": chosen_frames,
            "fps": (1000.0 * chosen_frames) / total_ms,
            "colors": chosen_colors,
            "size_kb": len(last_bytes) / 1024.0,
            "encode_ms": (time.perf_counter() - t0) * 1000.0,
        }
        return last_bytes, preview_rgba, meta
