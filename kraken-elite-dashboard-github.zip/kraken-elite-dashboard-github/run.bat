@echo off
cd /d "%~dp0"
powershell -NoProfile -Command "Start-Process pythonw -ArgumentList '\"%~dp0main.py\"' -Verb RunAs"
