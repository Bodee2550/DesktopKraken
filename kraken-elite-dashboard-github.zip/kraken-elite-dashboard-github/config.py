from __future__ import annotations

import copy
import json
import os
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

APP_DIR = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).parent
CONFIG_PATH = APP_DIR / "config.json"


@dataclass
class SideConfig:
    label_mode: str = "auto"           # "auto" | "custom"
    custom_label: str = ""
    arc_metric: str = "cpu_temp"       # Metric key from sensors.METRICS
    arc_min: float = 25.0
    arc_max: float = 95.0
    row1_metric: str = "cpu_temp"
    row2_metric: str = "cpu_load"
    arc_color: str = "#00AEF0"         # Cool / base arc color
    use_gradient: bool = True          # Smooth thermal gradient (Cool -> Warm -> Red)
    arc_mid_color: str = "#FFB800"     # Mid / warm color
    arc_hot_color: str = "#FF2424"     # High / warning red color
    icon_color: str = "#73CDFF"


@dataclass
class ProfileConfig:
    name: str = "Dual Info Default"
    bg_path: str = ""
    bg_dim: float = 0.28               # 0.0 (no dim) .. 0.85 (very dark)
    bg_fit: str = "cover"              # "cover" | "contain" | "stretch"
    bg_scale: float = 1.0              # 0.5 .. 2.0 zoom factor
    bg_offset_x: int = 0               # -320 .. +320 px
    bg_offset_y: int = 0               # -320 .. +320 px
    brightness: int = 100              # 0 .. 100 %
    orientation: int = 0               # 0 | 90 | 180 | 270
    arc_width: int = 24                # 10 .. 40 px
    font_family: str = "Bahnschrift"
    text_shadow: bool = True
    text_outline: bool = True
    show_divider: bool = True
    update_interval_sec: float = 1.0   # Static image refresh rate
    gif_update_interval_sec: float = 2.0  # Min interval between GIF bucket swaps
    gif_max_frames: int = 60           # Max frames kept from animated GIFs (12..90)
    left: SideConfig = field(
        default_factory=lambda: SideConfig(
            label_mode="auto",
            custom_label="",
            arc_metric="cpu_temp",
            arc_min=25.0,
            arc_max=95.0,
            row1_metric="cpu_temp",
            row2_metric="cpu_load",
            arc_color="#00AEF0",
            use_gradient=True,
            arc_mid_color="#FFB800",
            arc_hot_color="#FF2424",
            icon_color="#73CDFF",
        )
    )
    right: SideConfig = field(
        default_factory=lambda: SideConfig(
            label_mode="auto",
            custom_label="",
            arc_metric="gpu_temp",
            arc_min=25.0,
            arc_max=90.0,
            row1_metric="gpu_temp",
            row2_metric="gpu_load",
            arc_color="#7AB800",
            use_gradient=True,
            arc_mid_color="#FFB800",
            arc_hot_color="#FF2424",
            icon_color="#B2E05C",
        )
    )


@dataclass
class AppConfig:
    active_profile: str = "Dual Info Default"
    blank_on_sleep: bool = True
    minimize_to_tray_on_close: bool = True
    profiles: dict[str, ProfileConfig] = field(default_factory=dict)

    def ensure_default_profile(self) -> None:
        if not self.profiles:
            default = ProfileConfig()
            self.profiles[default.name] = default
            self.active_profile = default.name
        elif self.active_profile not in self.profiles:
            self.active_profile = next(iter(self.profiles))

    def current_profile(self) -> ProfileConfig:
        self.ensure_default_profile()
        return self.profiles[self.active_profile]


def _side_from_dict(data: dict[str, Any], default: SideConfig) -> SideConfig:
    merged = asdict(default)
    for key in merged:
        if key in data:
            merged[key] = data[key]
    return SideConfig(**merged)


def _profile_from_dict(name: str, data: dict[str, Any]) -> ProfileConfig:
    base = ProfileConfig(name=name)
    kwargs = asdict(base)
    kwargs.pop("left")
    kwargs.pop("right")
    for key in list(kwargs.keys()):
        if key in data:
            kwargs[key] = data[key]
    kwargs["name"] = name
    left = _side_from_dict(data.get("left", {}), base.left)
    right = _side_from_dict(data.get("right", {}), base.right)
    return ProfileConfig(**kwargs, left=left, right=right)


def load_config(path: Path = CONFIG_PATH) -> AppConfig:
    if not path.exists():
        cfg = AppConfig()
        cfg.ensure_default_profile()
        save_config(cfg, path)
        return cfg

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        profiles: dict[str, ProfileConfig] = {}
        for pname, pdata in raw.get("profiles", {}).items():
            if isinstance(pdata, dict):
                profiles[pname] = _profile_from_dict(pname, pdata)
        cfg = AppConfig(
            active_profile=str(raw.get("active_profile", "Dual Info Default")),
            blank_on_sleep=bool(raw.get("blank_on_sleep", True)),
            minimize_to_tray_on_close=bool(raw.get("minimize_to_tray_on_close", True)),
            profiles=profiles,
        )
        cfg.ensure_default_profile()
        return cfg
    except Exception:
        cfg = AppConfig()
        cfg.ensure_default_profile()
        return cfg


def save_config(cfg: AppConfig, path: Path = CONFIG_PATH) -> None:
    cfg.ensure_default_profile()
    payload = {
        "active_profile": cfg.active_profile,
        "blank_on_sleep": cfg.blank_on_sleep,
        "minimize_to_tray_on_close": cfg.minimize_to_tray_on_close,
        "profiles": {name: asdict(prof) for name, prof in cfg.profiles.items()},
    }
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def clone_config(cfg: AppConfig) -> AppConfig:
    return copy.deepcopy(cfg)
