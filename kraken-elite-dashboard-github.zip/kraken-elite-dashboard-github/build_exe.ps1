# Optional: build a standalone Windows .exe (requires: pip install pyinstaller)
$ErrorActionPreference = "Stop"
pyinstaller `
    --noconfirm `
    --windowed `
    --onedir `
    --name "KrakenEliteDashboard" `
    --uac-admin `
    --add-data "lhm;lhm" `
    --collect-all libusb_package `
    --hidden-import clr `
    --hidden-import pythonnet `
    main.py
Write-Host "[OK] Built dist\KrakenEliteDashboard\KrakenEliteDashboard.exe" -ForegroundColor Green
